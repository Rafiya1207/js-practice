function decodeInteger(listString, integer, index ) {
  if (listString[index] === 'e') {
    return integer;
  }

  integer = integer + listString[index];

  return decodeInteger(listString, integer, index + 1);
}

function decodeList(listString, list, index) {
  if (listString[index] === 'e') {
    return list;
  }

  if (listString[index] === 'i') {
    
  }

  return decodeList(listString, list, index + 1);
}

console.log(decodeList('le', [], 0));