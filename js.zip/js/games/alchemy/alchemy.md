|ingredient1|ingredient2|result|
|------|-----|------|
|fire|earth|lava|
|fire|water|steam|
|earth|water|mud/clay|
|air|earth|dust|
|air|air|pressure|

|air|lava|stone|
|air|steam|cloud|
|air|stone|sand|

|air|steel|rust|
|air|wave|sound|
|metal|stone|blade|
|blade|wood|Axe|
|Human|Bird|Angel|
|life|space|alien|