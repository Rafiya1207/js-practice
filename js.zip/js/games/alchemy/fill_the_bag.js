const EMOJIPEDIA = [
  ['fire', '🔥'],
  ['air', '💨'],
  ['water', '💧'],
  ['earth', '🌎'],
  ['lava', '🌋'],
  ['steam', '♨️'],
  ['stone', '🪨'],
  ['cloud', '☁️'],
];

function displayInstructions(ingredients) {
  for (let index = 0; index < ingredients.length; index++) {
    const ingredient = ingredients[index];
    console.log(`-->  ${ingredient[0]} - ${ingredient[1]}`);
  }
  console.log();
}

function getEmoji(meaning, emojigipedia) {
  for (let index = 0; index < emojigipedia.length; index++) {
    if (meaning === emojigipedia[index][0]) {
      return emojigipedia[index][1];
    }
  }
}

function getEmojis(meanings, emojigipedia) {
  const emojis = [];
  for (let index = 0; index < meanings.length; index++) {
    emojis.push(getEmoji(meanings[index], emojigipedia));
  }
  return emojis;
}

function displayEmojis(emojis, emojigipedia, message) {
  console.log(`${message}: ${getEmojis(emojis, emojigipedia)} \n`);
}

function askForIngredients() {
  const ingredient1 = prompt('1st ingredient: ');
  const ingredient2 = prompt('2nd ingredient: ');

  return [ingredient1, ingredient2];
}

function areValidIngredients(ingredient1, ingredient2, bag) {
  return bag.includes(ingredient1) && bag.includes(ingredient2);
}

function askForResultant() {
  return prompt('Enter resultant combination: ');
}

function isValidResultant(resultant, resultants) {
  return resultants.includes(resultant);
}

function isValidCombination(ingredient1, ingredient2, resultant, combinations) {
  for (let index = 0; index < combinations.length; index++) {
    const currentIng1 = combinations[index][0];
    const currentIng2 = combinations[index][1];
    const currentResultant = combinations[index][2];

    const isIng1InCombination = (currentIng1 === ingredient1 || currentIng2 === ingredient1);
    const isIng2InCombination = (currentIng1 === ingredient2 || currentIng2 === ingredient2);

    if (isIng1InCombination && isIng2InCombination && currentResultant === resultant) {
      return true;
    }
  }
  return false;
}

function addToBag(bag, ingredient) {
  bag.push(ingredient);
}

function deleteResultant(resultant, resultants) {
  const modified = [];

  for (let index = 0; index < resultants.length; index++) {
    if (resultants[index] !== resultant) {
      modified.push(resultants[index]);
    }
  }
  return modified;
}

function game(bag, resultants, combinations, emojigipedia) {
  if (resultants.length === 0) {
    console.log(`🎉 HURRAY! You filled your Bag`);
    return;
  }

  console.log('-'.repeat(30));
  displayEmojis(bag, emojigipedia, 'Bag');
  displayEmojis(resultants, emojigipedia, 'Resultants');

  const ingredient1 = prompt('1st ingredient: ');
  const ingredient2 = prompt('2nd ingredient: ');

  if (!areValidIngredients(ingredient1, ingredient2, bag)) {
    console.log(`ingredients are not in your bag`);
    game(bag, resultants, combinations, emojigipedia);
    return;
  }

  const resultant = prompt('Enter resultant compound: ');

  // console.log(resultant, resultants);
  
  if (!isValidResultant(resultant, resultants)) {
    console.log(`resultant is not in provided`);
    game(bag, resultants, combinations, emojigipedia);
    return;
  }

  if (!isValidCombination(ingredient1, ingredient2, resultant, combinations)) {
    console.log(`Incorrect combination`);
    game(bag, resultants, combinations, emojigipedia);
    return;
  }

  addToBag(bag, resultant);
  // console.log(bag);
  
  const newResultants = deleteResultant(resultant, resultants);
  // console.log(newResultants);
  
  // displayEmojis(bag, emojigipedia, 'Bag');
  game(bag, newResultants, combinations, emojigipedia);
  
}

function main() {
  const bag = ['fire', 'air', 'earth', 'water'];
  const resultants = ['lava', 'steam', 'stone', 'cloud'];

  const combinations = [
    ['fire', 'earth', 'lava'],
    ['fire', 'water', 'steam'],
    ['air', 'lava', 'stone'],
    ['air', 'steam', 'cloud'],
  ];

  displayInstructions(EMOJIPEDIA);
  game(bag, resultants, combinations, EMOJIPEDIA);

}

main();