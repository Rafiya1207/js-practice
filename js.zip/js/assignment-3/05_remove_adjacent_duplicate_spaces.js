/*
  Implement the below function to replace every run of adjacent SPACE(" ")
  characters with a single SPACE in the given sentence.

  Rules:
  - Consider only the plain SPACE character (" "). Any contiguous sequence
    of one or more SPACE characters should become a single SPACE.
  - Leading and trailing runs of spaces are also collapsed to a single space.
  - Do NOT modify other whitespace characters: TAB("\t") and NEW LINE("\n")
    must remain exactly as they are.
  - Runs of spaces that are separated by other characters (including \t or \n)
    are treated separately and each such run is collapsed independently.

  Examples:
  removeAdjacentDuplicateSpaces("statement      with    two spaces")
    -> "statement with two spaces"
    (multiple spaces between words collapsed to single spaces)

  removeAdjacentDuplicateSpaces("   hello   world   ")
    -> " hello world "
    (leading/trailing runs collapsed to single leading/trailing space)
*/

function removeAdjacentDuplicateSpaces(sentence) {
  // Implementation here.
  let modifiedString = "";

  for (let index = 0; index < sentence.length; index++) {
    let currentCharacter = sentence[index];

    if (currentCharacter === " " && sentence[index + 1] === " ") {
      currentCharacter = "";
    }
    modifiedString += currentCharacter;
  }
  return modifiedString;
}

function composeMessage(sentence, expectedResult, actualResult) {
  const resultCharacter = expectedResult === actualResult ? "✅" : "❌";
  const inputMessage = " [" + sentence + "]";
  const resultMessage = " | " + expectedResult + " | " + actualResult;

  return resultCharacter + inputMessage + resultMessage;
}

function testRemoveAdjacentDuplicateSpaces(sentence, expectedResult) {
  const actualResult = removeAdjacentDuplicateSpaces(sentence);

  console.log(composeMessage(sentence, expectedResult, actualResult));
}

function testAll() {
  testRemoveAdjacentDuplicateSpaces("abc      def    ", "abc def ");
  testRemoveAdjacentDuplicateSpaces("   hello   world   ", " hello world ");
  testRemoveAdjacentDuplicateSpaces("   hello \t war   ", " hello \t war ");
  testRemoveAdjacentDuplicateSpaces(" h  \t   world   ", " h \t world ");
  testRemoveAdjacentDuplicateSpaces("  hell  \t     \n   ", " hell \t \n ");
  testRemoveAdjacentDuplicateSpaces("  hell  \t\n   ", " hell \t\n ");
}

testAll();