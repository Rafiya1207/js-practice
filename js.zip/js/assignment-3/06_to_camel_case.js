/*
  Implement the below function to convert a string from snake_case
  format into camelCase format.

  Example:
  toCamelCase("hello_wORLd_pro1gram")
    -> "helloWorldPro1gram"
*/

function toUpperCase(character) {
  const upperCaseLetters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const lowerCaseLetters = 'abcdefghijklmnopqrstuvwxyz';

  for (let index = 0; index < lowerCaseLetters.length; index++) {
    if (lowerCaseLetters[index] === character) {
      return upperCaseLetters[index];
    }
  }
  return character;
}

function toLowerCase(character) {
  const upperCaseLetters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const lowerCaseLetters = 'abcdefghijklmnopqrstuvwxyz';

  for (let index = 0; index < upperCaseLetters.length; index++) {
    if (upperCaseLetters[index] === character) {
      return lowerCaseLetters[index];
    }
  }
  return character;
}

function toCamelCase(sentence) {
  let camelCase = '';
  let index = 0;

  while (sentence[index] === '_') {
    index++;
  }

  camelCase += toLowerCase(sentence[index]);
  index++;

  while (index < sentence.length) {
    let currentCharacter = toLowerCase(sentence[index]);
    
    if(sentence[index] === '_') {
      currentCharacter = '';
    }

    if(sentence[index] !== '_' && sentence[index - 1] === '_') {
      currentCharacter = toUpperCase(sentence[index]);
    }
    camelCase += currentCharacter;
    index++;
  }

  return camelCase;
}

function composeMessage(sentence, expectedResult, actualResult) {
  const resultCharacter = expectedResult === actualResult ? '✅' : '❌';
  const inputMessage = ' [' + sentence + ']';
  const resultMessage = ' | ' + expectedResult + ' | ' + actualResult;

  return resultCharacter + inputMessage + resultMessage;
}

function testToCamelCase(sentence, expectedResult) {
  const actualResult = toCamelCase(sentence);

  console.log(composeMessage(sentence, expectedResult, actualResult));
}

function testAll() {
  testToCamelCase('hello_world', 'helloWorld');
  testToCamelCase('hello', 'hello');
  testToCamelCase('_hello_world', 'helloWorld');
  testToCamelCase('heLlo_wORLd', 'helloWorld');
  testToCamelCase('heLlo____wORLd__', 'helloWorld');
  testToCamelCase('heLlo_wORLd__', 'helloWorld');
  testToCamelCase('hello_wORLd_pro1gram', 'helloWorldPro1gram');
  testToCamelCase('hellowORLdpro1gram', 'helloworldpro1gram');
  testToCamelCase('Hello_wORLdpro1gram', 'helloWorldpro1gram');
}

testAll();