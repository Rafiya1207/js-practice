/*
  Implement the below function to reverse the given sentence.
  Examples:
  reverseString("hello") returns "ollhe"
*/

function reverseString(sentence) {
  let reversedString = "";

  for (let index = sentence.length - 1; index >= 0; index--) {
    reversedString += sentence[index];
  }

  return reversedString;
}

function composeMessage(sentence, expectedResult, actualResult) {
  const resultCharacter = expectedResult === actualResult ? "✅" : "❌";
  const inputMessage = " [" + sentence + "]";
  const resultMessage = " | " + expectedResult + " | " + actualResult;

  return resultCharacter + inputMessage + resultMessage;
}

function testReverseString(sentence, expectedResult) {
  const actualResult = reverseString(sentence);

  console.log(composeMessage(sentence, expectedResult, actualResult));
}

function testAll() {
  testReverseString("hello", "olleh");
  testReverseString("olleh", "hello");
  testReverseString("a", "a");
  testReverseString("ab", "ba");
  testReverseString("aa", "aa");
  testReverseString("", "");
  testReverseString("a b aa", "aa b a");
  testReverseString("a b  aa", "aa  b a");
  testReverseString("  ", "  ");
  testReverseString("112234", "432211");
}

testAll();