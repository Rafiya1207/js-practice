/*
  Implement the below function to trim(remove all leading and trailing 
  whitespaces) from the given sentence.
  A whitespace is SPACE(" "), NEW LINE("\n"), TAB("\t")
  Examples:
  reverseString(" hello world\n") returns "hello world"
*/

function countLeadingSpaces(sentence) {
  let index = 0;

  while (isWhitespace(sentence[index])) {
    index++;
  }
  return index;
}

function countTrailingSpaces(sentence) {
  let index = sentence.length - 1;
  let trailingSpaces = 0;

  while (isWhitespace(sentence[index])) {
    trailingSpaces++;
    index--;
  }
  return trailingSpaces;
}

function slice(string, start, end) {
  let slicedString = '';

  for (let index = start; index < end; index++) {
    slicedString += string[index];
  }
  return slicedString;
}

function trim(sentence) {
  const noOfLeadingSpaces = countLeadingSpaces(sentence);
  const noOfTrailingSpaces = countTrailingSpaces(sentence);
  const endIndex = sentence.length - noOfTrailingSpaces;

  return slice(sentence, noOfLeadingSpaces, endIndex);
}

function composeMessage(sentence, expectedResult, actualResult) {
  const resultCharacter = expectedResult === actualResult ? "✅" : "❌";
  const inputMessage = " [" + sentence + "]";
  const resultMessage = " | " + expectedResult + " | " + actualResult;

  return resultCharacter + inputMessage + resultMessage;
}

function testTrim(sentence, expectedResult) {
  const actualResult = trim(sentence);

  console.log(composeMessage(sentence, expectedResult, actualResult));
}

function testAll() {
  testTrim(" hello world\n", "hello world");
  testTrim("  hello world\n  ", "hello world");
  testTrim("  hello world\n  \t \t", "hello world");
  testTrim("  ", "");
  testTrim(" a", "a");
}

testAll();