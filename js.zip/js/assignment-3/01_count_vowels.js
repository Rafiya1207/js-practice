/*
  Implement the below function to count number of vowels present in the
  give sentence.
  Examples:
  countVowels("hello world") returns 3
  countVowels("hEllo wOrld") returns 3
*/

function isVowel(character) {
  const vowels = 'aeiouAEIOU';

  for (let index = 0; index < vowels.length; index++) {
    if (character === vowels[index]) {
      return true;
    }
  }
  return false;
}

function countVowels(sentence) {
  let vowelCount = 0;

  for (let index = 0; index < sentence.length; index++) {
    if (isVowel(sentence[index])) {
      vowelCount++;
    }
  }

  return vowelCount;
}

function composeMessage(sentence, expectedResult, actualResult) {
  const resultCharacter = expectedResult === actualResult ? "✅" : "❌";
  const inputMessage = " [" + sentence + "]";
  const resultMessage = " | " + expectedResult + " | " + actualResult;

  return resultCharacter + inputMessage + resultMessage;
}

function testCountVowels(sentence, expectedResult) {
  const actualResult = countVowels(sentence);

  console.log(composeMessage(sentence, expectedResult, actualResult));
}

function testAll() {
  testCountVowels("hello world", 3);
  testCountVowels("hEllo wOrld", 3);
  testCountVowels("a", 1);
  testCountVowels("ab", 1);
  testCountVowels("abee", 3);
  testCountVowels("b", 0);
  testCountVowels("bcdfghj", 0);
  testCountVowels(" ", 0);
  testCountVowels("", 0);
  testCountVowels("aaaaa", 5);
}

testAll();