/*
  Implement the below function to count the number of words
  in the given sentence.

  Rules:
  - A word is defined as a sequence of non-whitespace characters.
  - Whitespace includes SPACE(" "), TAB("\t"), and NEW LINE("\n").
  - Multiple consecutive whitespace characters should be treated
    as a single separator.
  - Leading and trailing whitespace should not affect the word count.

  Example:
  countWords("hello   \t   world \n test")
    -> 3
*/

function isWhitespace(character) {
  switch (character) {
    case ' ': ;
    case '\n': ;
    case '\t': ;
      return true;
    default: return false;
  }
}

function countLeadingSpaces(sentence) {
  let index = 0;

  while (isWhitespace(sentence[index])) {
    index++;
  }
  return index;
}

function countTrailingSpaces(sentence) {
  let index = sentence.length - 1;
  let trailingSpaces = 0;

  while (isWhitespace(sentence[index])) {
    trailingSpaces++;
    index--;
  }
  return trailingSpaces;
}

function slice(string, start, end) {
  let slicedString = '';

  for (let index = start; index < end; index++) {
    slicedString += string[index];
  }
  return slicedString;
}

function trim(sentence) {
  const noOfLeadingSpaces = countLeadingSpaces(sentence);
  const noOfTrailingSpaces = countTrailingSpaces(sentence);
  const endIndex = sentence.length - noOfTrailingSpaces;
  
  return slice(sentence, noOfLeadingSpaces, endIndex);
}

function isWord() {
  
}

function countWords(sentence) {
  let wordCount = 0;
  const trimmed = trim(sentence);

  if (trimmed === "") {
    return wordCount;
  }

  for (let index = 0; index < trimmed.length; index++) {
    if (isWhitespace(trimmed[index]) && (!isWhitespace(trimmed[index-1]))) {
      wordCount++;
    }
  }

  wordCount++;
  return wordCount;
}

function composeMessage(sentence, expectedResult, actualResult) {
  const resultCharacter = expectedResult === actualResult ? "✅" : "❌";
  const inputMessage = " [" + sentence + "]";
  const resultMessage = " | " + expectedResult + " | " + actualResult;

  return resultCharacter + inputMessage + resultMessage;
}

function testCountWords(sentence, expectedResult) {
  const actualResult = countWords(sentence);

  console.log(composeMessage(sentence, expectedResult, actualResult));
}

function testAll() {
  testCountWords("hello   \t   world \n test", 3);
  testCountWords("hello   \t   world \n   test", 3);
  testCountWords("hello   \t   world \n test ", 3);
  testCountWords("    hello   \t   world \n test ", 3);
  testCountWords("    hello   \t\n \n  \n ", 1);
  testCountWords("    ", 0);
  testCountWords(" \n \n \t    ", 0);
  testCountWords("hello", 1);
}

testAll();