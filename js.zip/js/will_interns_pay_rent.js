const noOfRepairs = 4;
const noOfRepairsDone = 2;

const willInternsPayRent = (noOfRepairs === noOfRepairsDone);
console.log(willInternsPayRent);
