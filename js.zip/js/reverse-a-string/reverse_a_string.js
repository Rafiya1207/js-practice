const string = "a c";
let reversedString = "";
let index = 1;

reversedString = reversedString + string[string.length - index];
index = index + 1;

reversedString = reversedString + string[string.length - index];
index = index + 1;

reversedString = reversedString + string[string.length - index];
index = index + 1;

console.log(reversedString);