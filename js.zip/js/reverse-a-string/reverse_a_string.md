input              | output

"ab"               | "ba" 
"abc"              | "cba"
"a c"              | "c a"
"olleh"            | "hello" 
"reverse a string" | "gnirts a esrever"
"abc d  ef"        | "fe  d c"
"12abc*+-/"        | "/-+*cba21"
" "                | " "
"a"                | "a"

