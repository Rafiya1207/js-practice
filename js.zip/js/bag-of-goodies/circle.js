function x1(y, amplitude, wavelength) {
  return amplitude + Math.floor(amplitude * Math.sin(y * wavelength));
}
function x2(y, amplitude, wavelength) {
  return amplitude + Math.floor(amplitude * Math.cos(y * wavelength));
}

function dnaPair(config) {
  const x1 = config[0];
  // const x2 = config[1];
  const l = config[1];
  // const r = config[3];
  // return ' '.repeat(x1) + l + ' '.repeat(Math.abs(x2 - x1)) + l;
  return ' '.repeat(x1) + l;
}

function dnaStrand(diameter, amplitude, wavelength) {
  const pairs = [];
  for (let i = 0; i < diameter; i++) {
    const k1 = x1(i, amplitude/ 2, wavelength);
    // const k2 = x2(i, amplitude/2, wavelength);
    // let config = k1 < k2 ? [k1, k2, '🔵', '🟡'] : [k2, k1, '🟡', '🔵'];
    let config = [k1, '0'];
    pairs.push(dnaPair(config));
  }

  return pairs;
}

function main() {
  const strand = dnaStrand(40, 28, 0.2);
  console.log(strand.join('\n'));
}

// main();

function points(angle, radius) {
  const x = radius + Math.floor(radius * Math.cos(angle));
  const y = radius + Math.floor(radius * Math.sin(angle));
  console.log(`${angle} : (${x}, ${y})`);
  
  return [x, y]
}

for (let x = 0; x <= 10; x++) {
  console.log(y(x))
  points(angle, 5)
  // console.log(points(angle, 5));
}

