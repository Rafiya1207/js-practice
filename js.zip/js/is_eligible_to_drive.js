const age = 10;
const isEligibleToDrive = (age > 18) ? "yes" : "no";

console.log(isEligibleToDrive);
