function delay() {
  for (let index = 0; index < 900000000; index++) {}
}

