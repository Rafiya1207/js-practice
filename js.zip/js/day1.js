100.67897;

"hello";

console.log('hello world');