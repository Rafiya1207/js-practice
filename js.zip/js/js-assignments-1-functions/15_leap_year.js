function isDivisible(dividend, divisor) {
  return dividend % divisor === 0;
}

function isLeapYear(year) {
  const isDivisibleBy4 = isDivisible(year, 4);
  const isACenturyYear = isDivisible(year, 100);
  const isDivisibleBy400 = isDivisible(year, 400);
  
  return (isDivisibleBy4 && !isACenturyYear) || isDivisibleBy400;
}

function composeMessage(year, expectedResult, receivedResult) {
  const resultCharacter = receivedResult === expectedResult ? "✅" : "❌";
  const message = resultCharacter + " | year " + year + " | expectedResult " + expectedResult + " | receivedResult " + receivedResult + "\n";
  return message;
}

function testIsLeapYear(year, expectedResult) {
  const receivedResult = isLeapYear(year);
  console.log(composeMessage(year, expectedResult, receivedResult));
}

function testAll() {
  console.log("is leap year");
  testIsLeapYear(2000, true);
  testIsLeapYear(2400, true);
  testIsLeapYear(2500, false);
  testIsLeapYear(500, false);
  testIsLeapYear(100, false);
  testIsLeapYear(7, false);
  testIsLeapYear(4, true);
}

testAll();