function isCommonFactor(number1, number2, factor) {
  return number1 % factor === 0 && number2 % factor === 0;
}

function minimum(number1, number2) {
  return (number1 < number2) ? number1 : number2;
}

function HCF(number1, number2) {
  let factor = minimum(number1, number2);

  while (factor > 0) {
    if (isCommonFactor(number1, number2, factor)) {
      return factor;
    }
    factor--;
  }
}

function composeMessage(number1, number2, expectedResult, receivedResult) {
  const resultCharacter = receivedResult === expectedResult ? "✅" : "❌";
  const message = resultCharacter + " | number1: " + number1 + ", number2: " + number2 + " | expectedResult: " + expectedResult + " | receivedResult: " + receivedResult + "\n";
  return message;
}

function testHCF(number1, number2, expectedResult) {
  const obtainedResult = HCF(number1, number2);
  console.log(composeMessage(number1, number2, expectedResult, obtainedResult));
}

function testAll() {
  console.log("Tests for HCF of two numbers");
  testHCF(2, 3, 1);
  testHCF(12, 3, 3);
  testHCF(21, 13, 1);
  testHCF(1, 1, 1);
  testHCF(2, 2, 2);
  testHCF(1, 2, 1);
}

testAll();