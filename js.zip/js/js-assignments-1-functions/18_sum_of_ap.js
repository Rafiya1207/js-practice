function addTwoNumbers(number1, number2) {
  return number1 + number2;
}

function sumOfAP(firstTerm, difference, nTerms) {
  let sum = 0;
  let term = firstTerm;
  
  for (let currentTerm = 0; currentTerm < nTerms; currentTerm++) {
    sum = addTwoNumbers(sum, term);
    term = addTwoNumbers(term, difference);
  }

  return sum;
}

function composeMessage(firstTerm, difference, nTerms, expectedResult, receivedResult) {
  const resultCharacter = receivedResult === expectedResult ? "✅" : "❌";
  const message = resultCharacter + "Sum of first " + nTerms + " terms where" + " first term is " + firstTerm +  " difference is " + difference + " should be " + expectedResult + " and was " + receivedResult + "\n";
  return message;
}

function testIsSumOfAP(firstTerm, difference, nTerms, expectedResult) {
  const receivedResult = sumOfAP(firstTerm, difference, nTerms,);
  console.log(composeMessage(firstTerm, difference, nTerms, expectedResult, receivedResult));
}

function testAll() {
  testIsSumOfAP(0, 1, 1, 0);
  testIsSumOfAP(0, 1, 0, 0);
  testIsSumOfAP(5, 3, 2, 13);
  testIsSumOfAP(3, 2, 4, 24);
  testIsSumOfAP(2, 2, 4, 20);
  testIsSumOfAP(1, 1, 5, 15);
}

testAll();