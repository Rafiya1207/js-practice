function isDivisible(dividend, divisor) {
  return dividend % divisor === 0;
}

function isPrime(integerNumber) {
  if (integerNumber <= 1) {
    return false;
  }

  for (let factor = 2; factor < integerNumber; factor++) {
    if (isDivisible(integerNumber, factor)) {
      return false;
    }
  }
  return true;
}

function findFirstPrimeAbove(integerNumber) {
  let nextNumber = integerNumber + 1;
  let hasPrimeNotFound = true;

  while (hasPrimeNotFound) {
    if (isPrime(nextNumber)) {
      hasPrimeNotFound = false;
      return nextNumber;
    }

    nextNumber++;
  }
}

function composeMessage(integerNumber, expectedResult, receivedResult) {
  const resultCharacter = receivedResult === expectedResult ? "✅" : "❌";
  const message = resultCharacter + " | number: " + integerNumber + " | expectedResult: " + expectedResult + " | receivedResult: " + receivedResult + "\n";
  return message;
}

function testFindAllPrimes(integerNumber, expectedResult) {
  const obtainedResult = findFirstPrimeAbove(integerNumber);
  console.log(composeMessage(integerNumber, expectedResult, obtainedResult));
}

function testAll() {
  console.log("Tests to find first Prime number Above");
  testFindAllPrimes(0, 2);
  testFindAllPrimes(1, 2);
  testFindAllPrimes(2, 3);
  testFindAllPrimes(3, 5);
  testFindAllPrimes(9, 11);
}

testAll();
