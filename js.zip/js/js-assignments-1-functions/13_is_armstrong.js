function countDigits(integerNumber) {
  return (integerNumber + "").length;
}

function divide(dividend, divisor) {
  return (dividend - (dividend % divisor)) / divisor;
}

function isArmstrong(integerNumber) {
  const noOfDigits = countDigits(integerNumber);
  let sum = 0;
  let quotient = integerNumber;
  
  while (quotient > 0) {
    const lastDigit = quotient % 10;
    quotient = divide(quotient, 10);
    sum = sum + (lastDigit ** noOfDigits);
  }
  
  return (integerNumber === sum);
}

function composeMessage(integerNumber, expectedResult, receivedResult) {
  const resultCharacter = receivedResult === expectedResult ? "✅" : "❌";
  const message = resultCharacter + " Armstrong of " + integerNumber + " should be " + expectedResult + " and was " + receivedResult + "\n";
  return message;
}

function testIsArmstrong(integerNumber, expectedResult) {
  const receivedResult = isArmstrong(integerNumber);
  console.log(composeMessage(integerNumber, expectedResult, receivedResult));
}

function testAll() {
  testIsArmstrong(0, true);
  testIsArmstrong(2, true);
  testIsArmstrong(22, false);
  testIsArmstrong(153, true);
  testIsArmstrong(370, true);
  testIsArmstrong(370, true);
  testIsArmstrong(377, false);
}

testAll();