function isDivisible(dividend, divisor) {
  return dividend % divisor === 0;
}

function isPrime(integerNumber) {
  if (integerNumber <= 1) {
    return false;
  }
  
  for (let factor = 2; factor < integerNumber; factor++) {
    if (isDivisible(integerNumber, factor)) {
      return false;
    }
  }
  return true;
}

function composeMessage(integerNumber, expectedResult, receivedResult) {
  const resultCharacter = receivedResult === expectedResult ? "✅" : "❌";
  const message = resultCharacter + " | number: " + integerNumber + " | expectedResult: " + expectedResult + " | receivedResult: " + receivedResult + "\n";
  return message;
}

function testIsPrime(integerNumber, expectedResult) {
  const obtainedResult = isPrime(integerNumber);
  console.log(composeMessage(integerNumber, expectedResult, obtainedResult));
}

function testAll() {
  console.log("Tests to check for Prime number");
  testIsPrime(2, true);
  testIsPrime(3, true);
  testIsPrime(9, false);
  testIsPrime(1, false);
  testIsPrime(0, false);
  testIsPrime(29, true);
}

testAll();