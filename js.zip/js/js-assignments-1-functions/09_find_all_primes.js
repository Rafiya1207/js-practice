function isDivisible(dividend, divisor) {
  return dividend % divisor === 0;
}

function isPrime(integerNumber) {
  if (integerNumber <= 1) {
    return false;
  }
  
  for (let factor = 2; factor < integerNumber; factor++) {
    if (isDivisible(integerNumber, factor)) {
      return false;
    }
  }
  return true;
}

function findPrimeNumbers(startOfRange, endOfRange) {
  let primeNumbers = "";

  for (let currentNumber = startOfRange; currentNumber <= endOfRange; currentNumber++) {
    if(isPrime(currentNumber)) {
      primeNumbers = primeNumbers + currentNumber + " ";
    }
  }
  return primeNumbers;
}

function composeMessage(start, end, expectedResult, receivedResult) {
  const resultCharacter = receivedResult === expectedResult ? "✅" : "❌";
  const message = resultCharacter + " | range: " + start + " - " + end + " | expectedResult: " + expectedResult + " | receivedResult: " + receivedResult + "\n";
  return message;
}

function testFindAllPrimes(startOfRange, endOfRange, expectedResult) {
  const obtainedResult = findPrimeNumbers(startOfRange, endOfRange);
  console.log(composeMessage(startOfRange, endOfRange, expectedResult, obtainedResult));
}

function testAll() {
  console.log("Tests to find all Prime numbers within a range");
  testFindAllPrimes(0, 1, "");
  testFindAllPrimes(1, 10, "2 3 5 7 ");
  testFindAllPrimes(2, 9, "2 3 5 7 ");
  testFindAllPrimes(3, 5, "3 5 ");
  testFindAllPrimes(3, 3, "3 ");
}

testAll();