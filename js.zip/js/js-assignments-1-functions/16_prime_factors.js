function divide(dividend, divisor) {
  return (dividend - (dividend % divisor)) / divisor;
}

function findPrimeFactors(integerNumber) {
  let dividend = integerNumber;
  let divisor = 2;
  let primeFactors = "";

  while (dividend > 1) {
    if (dividend % divisor === 0) {
      dividend = divide(dividend, divisor);
      primeFactors = primeFactors + divisor + " ";
    } else {
      divisor++;
    }
  }
  return primeFactors;
}

function composeMessage(integerNumber, expectedResult, receivedResult) {
  const resultCharacter = receivedResult === expectedResult ? "✅" : "❌";
  const message = resultCharacter + " | number: " + integerNumber + " | expectedResult: " + expectedResult + " | receivedResult: " + receivedResult + "\n";
  return message;
}

function testFindPrimeFactors(integerNumber, expectedResult) {
  const obtainedResult = findPrimeFactors(integerNumber);
  console.log(composeMessage(integerNumber, expectedResult, obtainedResult));
}

function testAll() {
  console.log("Tests to find prime factors");
  testFindPrimeFactors(0, "");
  testFindPrimeFactors(10, "2 5 ");
  testFindPrimeFactors(9, "3 3 ");
  testFindPrimeFactors(5, "5 ");
  testFindPrimeFactors(1, "");
}

testAll();