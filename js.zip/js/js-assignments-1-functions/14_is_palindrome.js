function divide(dividend, divisor) {
  return (dividend - (dividend % divisor)) / divisor;
}

function isPalindrome(integerNumber) {
  let reversedNumber = 0;
  let quotient = integerNumber;
  
  while (quotient > 0) {
    const lastDigit = quotient % 10;
    quotient = divide(quotient, 10);
    reversedNumber = reversedNumber * 10 + lastDigit;
  }
  
  return (reversedNumber === integerNumber);
}

function composeMessage(integerNumber, expectedResult, receivedResult) {
  const resultCharacter = receivedResult === expectedResult ? "✅" : "❌";
  const message = resultCharacter + " Palindrome of " + integerNumber + " should be " + expectedResult + " and was " + receivedResult + "\n";
  return message;
}

function testIsPalindrome(integerNumber, expectedResult) {
  const receivedResult = isPalindrome(integerNumber);
  console.log(composeMessage(integerNumber, expectedResult, receivedResult));
}

function testAll() {
  testIsPalindrome(0, true);
  testIsPalindrome(10, false);
  testIsPalindrome(22, true);
  testIsPalindrome(121, true);
  testIsPalindrome(220, false);
  testIsPalindrome(22222, true);
}

function main() {
  testAll();
}

main();