function nthFibonacci(n) {
  let currentTerm = 0;
  let futureTerm = 1;
  
  for (let termCount = 1; termCount < n; termCount++) {
    const nextTerm = currentTerm;
    currentTerm = futureTerm;
    futureTerm = currentTerm + nextTerm;
  }

  return currentTerm;
}
