function LCM(number1, number2) {
  let multiplier = 1;
  let multiple = number1;
  
  while (multiple <= number1 * number2) {
    multiple = number1 * multiplier;
  
    if(multiple % number2 === 0) {
      return multiple;
    }
    multiplier++;
  }
}

function composeMessage(number1, number2, expectedResult, receivedResult) {
  const resultCharacter = receivedResult === expectedResult ? "✅" : "❌";
  const message = resultCharacter + " | number1: " + number1 + ", number2: " + number2 + " | expectedResult: " + expectedResult + " | receivedResult: " + receivedResult + "\n";
  return message;
}

function testLCM(number1, number2, expectedResult) {
  const receivedResult = LCM(number1, number2);
  console.log(composeMessage(number1, number2, expectedResult, receivedResult));
}

function testAll() {
  console.log("LCM");
  testLCM(2, 3, 6);
  testLCM(2, 1, 2);
  testLCM(2, 4, 4);
  testLCM(4, 3, 12);
  testLCM(1, 3, 3);
  testLCM(1, 1, 1);
  testLCM(3, 3, 3);
}

testAll();