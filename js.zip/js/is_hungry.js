const isHungry = false;

if (isHungry) {
    console.log("eat food");
} else {
    console.log("make food");
}
