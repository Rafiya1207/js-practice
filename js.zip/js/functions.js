function greet(person) {
  console.log("hello", person);
}

function getPerson() {
  console.log("getting person..")
  return "jimmy";
}

function addTwoNumbers(a, b) {
  return a + b;
}

function multiplyTwoNumbers(a, b) {
  let product = 0;

  for (let i = 0; i < b; i = addTwoNumbers(i, 1)) {
    product = addTwoNumbers(product, a);
  }
  return product;
}

function subtract(x, y) {
  return x - y;
}

function divide(dividend, divisor) {
  let divisionCount = 0;
  let difference = dividend;

  while (difference > divisor) {
    difference = subtract(difference, divisor);
    divisionCount = addTwoNumbers(divisionCount, 1);
  }
  return divisionCount;
}

function getRemainder(dividend, divisor) {
  let divisionCount = 0;
  let difference = dividend;

  while (difference > divisor) {
    difference = subtract(difference, divisor);
    divisionCount = addTwoNumbers(divisionCount, 1);
  }
  return difference;
}

function moduloDivision(dividend, divisor) {
  return subtract(dividend, multiplyTwoNumbers(divisor, divide(dividend, divisor)));
}

function square(base) {
  return multiplyTwoNumbers(base, base);
}

function cube(base) {
  return multiplyTwoNumbers(multiplyTwoNumbers(base, base), base);
}

function power(base, power) {
  let product = 1;

  for (let i = 0; i < power; i++) {
    product = multiplyTwoNumbers(product, base);
  }
  return product;
}

// function distance

console.log("addition ", addTwoNumbers(2, 3));
console.log("multiplication ", multiplyTwoNumbers(-4, 0));
console.log("division", divide(16, 5));
console.log("modulo division 1", getRemainder(13, 5));
console.log("modulo division 2", moduloDivision(22, 15));
console.log("square", square(2));
console.log("cube", cube(2));
console.log("power", power(4, 0.5));

greet(getPerson() + "joe");