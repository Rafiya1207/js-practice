/*
  Implement the below function that
  creates a slice/substring using start and end indices

  Examples:
    slice('hello world', 0, 4) => 'hello'
    slice('negative start', -1, 8) => 'negative '
    slice('', 0, 10) => ''

  **Your function must return a value**

  It's not necessary to print the result on screen, 
  however to test your function you are free to print the result
*/

function slice(text, start, end) {
  // Implementation here.
  let slicedText = "";
  let startIndex = start;

  if (start <= 0) {
    startIndex = 0;
  }
  
  for (let index = startIndex; index <= end && index < text.length; index++) {
    slicedText += text[index];
  }
  return slicedText;
}

function composeMessage(text, start, end, expectedResult, receivedResult) {
  const resultCharacter = expectedResult === receivedResult ? "✅" : "❌";
  const message = resultCharacter + " | " + text + " | " + start + " | " + end + " | expected: " + expectedResult + " | received: " + receivedResult + "\n";
  return message;
}

function testSlice(text, start, end, expectedResult) {
  const receivedResult = slice(text, start, end);
  console.log(composeMessage(text, start, end, expectedResult, receivedResult));
}

function testAll() {
  testSlice("hello world", 0, 4, "hello");
  testSlice("hello world", -1, 4, "hello");
  testSlice(" ", -1, 4, " ");
  testSlice("no slice", -1, -1, "");
  testSlice("space  space", 2, 7, "ace  s");
  testSlice("", 0, 3, "");
  testSlice("slice e n d", 5, 10, " e n d");
  testSlice("he1lo w0rld", -1, 4, "he1lo");
}

testAll();