function findIndex(text, target) {
  for (let index = 0; index < text.length; index++) {
    if (text[index] === target) {
      return index;
    }
  }
  return -1;
}

function composeMessage(string, target, expectedResult, actualResult) {
  const resultCharacter = expectedResult === actualResult ? "✅" : "❌";
  const inputMessage = " | " + string + " | " + target;
  const resultMessage = " | " + expectedResult + " | " + actualResult;
  return "| " + resultCharacter + inputMessage + resultMessage;
}

function testFindIndex(text, target, expectedResult) {
  const receivedResult = findIndex(text, target);
  console.log(composeMessage(text, target, expectedResult, receivedResult));
}

function testAll() {
  testFindIndex("hello world", "h", 0);
  testFindIndex("hello world", "l", 2);
  testFindIndex("hello world", "o", 4);
  testFindIndex("hello world", " ", 5);
  testFindIndex("hello", " ", -1);
  testFindIndex(" ", " ", 0);
  testFindIndex(" ", "", -1);
  testFindIndex("tttttt", "t", 0);
}

testAll();