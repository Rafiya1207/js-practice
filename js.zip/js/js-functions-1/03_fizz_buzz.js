function isDivisible(dividend, divisor) {
  return dividend % divisor === 0;
}

function fizzBuzz(number) {
  const isDivisibleBy3 = isDivisible(number, 3);
  const isDivisibleBy5 = isDivisible(number, 5);
  const isDivisibleBy15 = isDivisible(number, 15);

  if (isDivisibleBy15) {
    return "fizzbuzz";
  }

  if (isDivisibleBy3) {
    return "fizz";
  }

  if (isDivisibleBy5) {
    return "buzz";
  }
  return number + "";
}

function composeMessage(number, expectedResult, receivedResult) {
  const resultCharacter = expectedResult === receivedResult ? "✅" : "❌";
  const message = resultCharacter + " | " + number + " | expected: " + expectedResult + " | received: " + receivedResult + "\n";
  return message;
}

function testFizzBuzz(number, expectedResult) {
  const receivedResult = fizzBuzz(number);
  console.log(composeMessage(number, expectedResult, receivedResult));
}

function testAll() {
  testFizzBuzz(3, "fizz");
  testFizzBuzz(5, "buzz");
  testFizzBuzz(15, "fizzbuzz");
  testFizzBuzz(7, "7");
}

testAll();