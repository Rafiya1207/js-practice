/*
  Write a function that counts the occurrence of a substring in a string

  Examples:
    occurrences('hello world', 'l') => 3
    occurrences('hello world', 'll') => 1
    occurrences('hello world', 'world') => 1
    occurrences('hello world', 'zebra') => 0

  **Your function must return a value**

  It's not necessary to print the result on screen, 
  however to test your function you are free to print the result
*/

function extractString(string, startIndex, noOfCharacters) {
  let extractedString = "";
  let substringIndex = startIndex;

  for (let iterator = 0; iterator < noOfCharacters; iterator++) {
    extractedString = extractedString + string[substringIndex];
    substringIndex++;
  }
  return extractedString;
}

function occurrences(string, substring) {
  // Implementation here.
  const substringLength = substring.length;
  const stringLength = string.length;

  if (substringLength === 0) {
    return 0;
  }

  let count = 0;
  for(let index = 0; index < stringLength; index++) {
    if (substringLength !== 0 && extractString(string, index, substringLength) === substring){
      count++;
    }
  }
  return count;
}

function composeMessage(string, substring, expectedResult, receivedResult) {
  const resultCharacter = expectedResult === receivedResult ? "✅" : "❌";
  const message = resultCharacter + " | " + string + " | " + substring + " | expected: " + expectedResult + " | received: " + receivedResult + "\n";
  return message;
}

function testOccurrences(string, substring, expectedResult) {
  const receivedResult = occurrences(string, substring);
  console.log(composeMessage(string, substring, expectedResult, receivedResult));
}

function testAll() {
  testOccurrences("hello world", "ll", 1);
  testOccurrences("hello world", "l", 3);
  testOccurrences("lllll", "ll", 4);
  testOccurrences("lllll", "llll", 2);
  testOccurrences("121212", "1", 3);
  testOccurrences("121212", "1", 3);
  testOccurrences("    ", " ", 4);
  testOccurrences(" h e l   l o", " l", 2);
  testOccurrences("world", "worlds", 0);
  testOccurrences("war", "wor", 0);
  testOccurrences("war", "", 0);
  testOccurrences("", "", 0);
}

testAll();