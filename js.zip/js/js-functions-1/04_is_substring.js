/*
  Implement the below function that tells if a string is substring of another string

  Usage:
    isSubstring('hello world', 'worl') => true
    isSubstring('repeating iiiiiiii', 'iii') => true
    isSubstring('not found', 'for') => false

  **Your function must return a value**

  It's not necessary to print the result on screen, 
  however to test your function you are free to print the result
*/

function extractString(string, startIndex, noOfCharacters) {
  let extractedString = "";
  let substringIndex = startIndex;

  for (let iterator = 0; iterator < noOfCharacters; iterator++) {
    extractedString = extractedString + string[substringIndex];
    substringIndex++;
  }
  return extractedString;
}

function isSubstring(string, subString) {
  // Implementation here.
  const substringLength = subString.length;
  const stringLength = string.length;

  if (substringLength === 0) {
    return false;
  }

  for (let index = 0; index < stringLength; index = index + 1) {
    if (extractString(string, index, substringLength) === subString) {
      return true;
    }
  }
  return false;
}

function composeMessage(string, substring, expectedResult, receivedResult) {
  const resultCharacter = expectedResult === receivedResult ? "✅" : "❌";
  const inputsMessage = " | " + string + " | " + substring;
  const resultMessage = " | expected: " + expectedResult + " | received: " + receivedResult;
  return resultCharacter + inputsMessage + resultMessage + "\n";
}

function testIsSubstring(string, substring, expectedResult) {
  const receivedResult = isSubstring(string, substring);
  console.log(composeMessage(string, substring, expectedResult, receivedResult));
}

function testAll() {
  testIsSubstring("hello world", "world", true);
  testIsSubstring("repeat", "e", true);
  testIsSubstring("repeat ee", "ee", true);
  testIsSubstring("repeat ee", " ", true);
  testIsSubstring("repeat ee", "ll", false);
  testIsSubstring("11111", "11", true);
  testIsSubstring("11", "11111", false);
  testIsSubstring(" ", "abc", false);
  testIsSubstring(" abc", "abc", true);
  testIsSubstring("ABC", "abc", false);
  testIsSubstring("Hello World", "world", false);
  testIsSubstring("Hello", "", false);
  testIsSubstring("", "", false);
}

testAll();