/*
  Implement the below function 
  that replaces a character `match` with another character `replacement`
  in a given text and returns a new string.

  Examples:
    replace('hello world', 'l', 'n') => 'henno world'
    replace('no spaces in here', ' ', '_') => 'no_spaces_in_here'
    replace('', 'd', 'e') => ''

  **Your function must return a value**

  It's not necessary to print the result on screen, 
  however to test your function you are free to print the result
*/

function replace(text, match, replacement) {
  // Implementation here.
  let replacedString = "";

  for (let index = 0; index < text.length; index++) {
    replacedString += (text[index] === match) ? replacement : text[index];
  }
  return replacedString;
}

function composeMessage(text, match, replacement, expectedResult, receivedResult) {
  const resultCharacter = expectedResult === receivedResult ? "✅" : "❌";
  const message = resultCharacter + " | " + text + " | " + match + " | " + replacement + " | expected: " + expectedResult + " | received: " + receivedResult + "\n";
  return message;
}

function testReplace(text, match, replacement, expectedResult) {
  const receivedResult = replace(text, match, replacement);
  console.log(composeMessage(text, match, replacement, expectedResult, receivedResult));
}

function testAll() {
  testReplace("h", "h", "n", "n");
  testReplace("h", "l", "n", "h");
  testReplace("hel", "l", "n", "hen");
  testReplace("lll", "l", "k", "kkk");
  testReplace("l_l", "_", " ", "l l");
  testReplace("lll", "_", " ", "lll");
  testReplace(" ", "f", "g", " ");
  testReplace("no spaces in here", " ", "_", "no_spaces_in_here");
  testReplace("no_spaces_in_here", "_", "", "nospacesinhere");
}

testAll();