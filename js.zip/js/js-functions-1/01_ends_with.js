function isSubstringAt(string, substring, position) {
  for (let index = 0; index < string.length; index++) {
    if(string[position + index] !== substring[index]){
      return false;
    }
  }
  return true;
}

function endsWith(string, substring) {
  const substringStart = string.length - substring.length;
  return isSubstringAt(string, substring, substringStart);
}

function composeMessage(string, substring, expectedResult, actualResult) {
  const resultCharacter = expectedResult === actualResult ? "✅" : "❌";
  const inputMessage = " [" + string + ", " + substring + "]";
  const resultMessage = " | " + expectedResult + " | " + actualResult;
  return resultCharacter + inputMessage + resultMessage;
}

function testEndsWith(string, substring, expectedResult) {
  const actualResult = endsWith(string, substring);
  console.log(composeMessage(string, substring, expectedResult, actualResult));
}

function testAll() {
  testEndsWith("hello world", "ld", true);
  testEndsWith("hello world", "world", true);
  testEndsWith("hello world", "hello world", true);
  testEndsWith("hello world", "wor", false);
  testEndsWith("hello world", "hello", false);
  testEndsWith("hello world", " ", false);
  testEndsWith("hello ", " ", true);
  testEndsWith("hello ", "o ", true);
  testEndsWith(" ", " ", true);
  testEndsWith("helLO", "LO", true);
  testEndsWith("helLO", "Lo", false);
  testEndsWith("he110", "hello", false);
}

testAll();