function detailedMessage(input, expected, actual, description) {
  const inputMessage = `input: [${input}] \n`;
  const resultMessage = `expected: ${expected}\nactual: ${actual}`;
  return `❌ ${description}\n${inputMessage}${resultMessage}`;
}

function composeMessage(input, expected, actual, description) {
  if (expected === actual) {
    return `✅${description}`;
  }
  return detailedMessage(input, expected, actual, description);
}

function testFunction(description, input, expected) {
  const actual = f(input);

  console.log(composeMessage(input, expected, actual, description));
}

function testAll() {

}

testAll();