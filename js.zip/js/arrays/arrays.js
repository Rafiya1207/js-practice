function isEqual(comparendOne, comparendTwo) {
  const isArray = typeof comparendOne === "object";
  const areEqual = comparendOne === comparendTwo;
  return areEqual || (isArray && areDeepEqual(comparendOne, comparendTwo));
}

// logic for comparing arrays
function areAllSame(arrayOne, arrayTwo, index) {
  const isEnd = index === arrayOne.length;
  const areEqual = isEqual(arrayOne[index], arrayTwo[index]);
  return isEnd || (areEqual && areAllSame(arrayOne, arrayTwo, index + 1));
}

function areValidArrays(arrayOne, arrayTwo) {
  const sameType = typeof arrayOne === typeof arrayTwo;
  const isArray = typeof arrayOne === "object";
  return isArray && sameType;
}

function areDeepEqual(arrayOne, arrayTwo) {
  if (!areValidArrays(arrayOne, arrayTwo)) {
    return false;
  }
  const sameLength = arrayOne.length === arrayTwo.length;
  return sameLength && areAllSame(arrayOne, arrayTwo, 0);
}