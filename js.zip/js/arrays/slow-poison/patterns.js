function printRow(columns, char) {
  return char.repeat(columns);
}

function join(thing1, thing2, separator = '\n') {
  return thing1 + separator + thing2;
}

function printHollowRow(columns) {
  if (columns === 1) {
    return '*';
  }

  let row = '*';

  for (let index = 1; index < columns - 1; index++) {
    row += ' ';
  }

  return row + '*';
}

function filledRectangle(rows, columns) {
  let rectangle = '';
  let separator = '';

  for (let row = 0; row < rows; row++) {
    rectangle = join(rectangle, printRow(columns, '*'), separator);
    separator = '\n';
  }
  return rectangle;
}

function hollowRectangle(columns, rows) {
  let rectangle = '';

  rectangle += printRow(columns, '*');

  for (let row = 1; row < rows - 1; row++) {
    rectangle = join(rectangle, printHollowRow(columns), '\n');
  }

  if (rows > 1) {
    rectangle = join(rectangle, printRow(columns, '*'), '\n');
  }

  return rectangle;
}

function alternatingRectagle(columns, rows, chars) {
  let rectangle = '';
  let separator = '';

  for (let row = 0; row < rows; row++) {
    let charIndex = row % chars.length;

    rectangle = join(rectangle, printRow(columns, chars[charIndex]), separator);
    separator = '\n';
  }

  return rectangle;
}

function triangle(size) {
  let pattern = '';
  let separator = '';

  for (let row = 1; row <= size; row++) {
    pattern = join(pattern, printRow(row, '*'), separator);
    separator = '\n';
  }
  return pattern;
}

function rightAlignedTriangle(size) {
  let pattern = '';
  let seperator = '';

  for (let row = 1; row <= size; row++) {
    pattern = join(pattern, printRow(row, '*').padStart(size), seperator);
    seperator = '\n';
  }
  return pattern;
}

function generatePattern(style, dimensions) {
  if (dimensions[0] === 0 || dimensions[1] === 0) {
    return '';
  }

  switch (style) {
    case 'filled-rectangle': return filledRectangle(dimensions[1], dimensions[0]);
    case 'hollow-rectangle': return hollowRectangle(dimensions[0], dimensions[1]);
    case 'alternating-rectangle': return alternatingRectagle(dimensions[0], dimensions[1], ['*', '-']);
    case 'space-alternating-rectangle': return alternatingRectagle(dimensions[0], dimensions[1], ['*', '-', ' ']);
    case 'triangle': return triangle(dimensions[0]);
    case 'right-aligned-triangle': return rightAlignedTriangle(dimensions[0]);
  }
}


function details(style, dimensions, expected, actual) {
  const inputMessage = `style: [${style}], dimensions: ${dimensions} \n`;
  const resultMessage = `expected: ${expected}\nactual: ${actual}`;
  return `${inputMessage}${resultMessage}`;
}

function composeMessage(style, dimensions, expected, actual, description) {
  const isPass = expected === actual;
  const symbol = isPass ? '✅' : '❌';
  const message = symbol + description + '\n';
  const testDetails = isPass ? '' : details(style, dimensions, expected, actual);

  return message + testDetails;
}

function testGeneratePattern(description, style, dimensions, expected) {
  const actual = generatePattern(style, dimensions);

  console.log(composeMessage(style, dimensions, expected, actual, description));
}

function detailsPrintRow(columns, expected, actual) {
  const inputMessage = `columns: [${columns}] \n`;
  const resultMessage = `expected: ${expected}\nactual: ${actual}`;
  return `${inputMessage}${resultMessage}`;
}

function composeMsgPrintRow(columns, expected, actual, description) {
  const isPass = expected === actual;
  const symbol = isPass ? '✅' : '❌';
  const message = symbol + description + '\n';
  const testDetails = isPass ? '' : detailsPrintRow(columns, expected, actual);

  return message + testDetails;
}

function testPrintRow(description, columns, expected) {
  const actual = printRow(columns, '*');

  console.log(composeMsgPrintRow(columns, expected, actual, description));
}

function detailsFilledRect(rows, columns, expected, actual) {
  const inputMessage = `rows: [${rows}], columns: [${columns}] \n`;
  const resultMessage = `expected: ${expected}\nactual: ${actual}`;
  return `${inputMessage}${resultMessage}`;
}

function composeMsgFilledRect(rows, columns, expected, actual, description) {
  const isPass = expected === actual;
  const symbol = isPass ? '✅' : '❌';
  const message = symbol + description + '\n';
  const testDetails = isPass ? '' : detailsFilledRect(rows, columns, expected, actual);

  return message + testDetails;
}

function testFilledRect(description, rows, columns, expected) {
  const actual = filledRectangle(rows, columns);

  console.log(composeMsgFilledRect(rows, columns, expected, actual, description));
}

function detailsHollowRect(columns, rows, expected, actual) {
  const inputMessage = `columns: [${columns}], rows: [${rows}]\n`;
  const resultMessage = `expected: ${expected}\nactual: ${actual}`;
  return `${inputMessage}${resultMessage}`;
}

function composeMsgHollowRect(columns, rows, expected, actual, description) {
  const isPass = expected === actual;
  const symbol = isPass ? '✅' : '❌';
  const message = symbol + description + '\n';
  const testDetails = isPass ? '' : detailsHollowRect(columns, rows, expected, actual);

  return message + testDetails;
}

function testHollowRect(description, columns, rows, expected) {
  const actual = hollowRectangle(columns, rows);

  console.log(composeMsgHollowRect(columns, rows, expected, actual, description));
}

function testAll() {
  console.log('filled rectangle\n', '-'.repeat(10));
  testFilledRect('1 row, 1 col', 1, 1, '*');
  testFilledRect('1 row, 2 col', 1, 2, '**');
  testFilledRect('2 row, 2 col', 2, 2, '**\n**');
  testFilledRect('4 row, 2 col', 4, 2, '**\n**\n**\n**');
  testFilledRect('0 cols', 4, 0, '');
  testFilledRect('0 rows', 0, 4, '');

  console.log('hollow rectangle\n', '-'.repeat(10));
  testHollowRect('4 col, 3 row', 4, 3, '****\n*  *\n****');
  testHollowRect('5 col, 4 row', 5, 4, '*****\n*   *\n*   *\n*****');
  testHollowRect('6 col, 2 row', 6, 2, '******\n******');
  testHollowRect('6 col, 1 row', 6, 1, '******');
  testHollowRect('1 col, 1 row', 1, 1, '*');

  console.log('generate pattern\n', '-'.repeat(10));
  testGeneratePattern('0 cols - FR', 'filled-rectangle', [0, 1], '');
  testGeneratePattern('0 rows - FR', 'filled-rectangle', [1, 0], '');

  testGeneratePattern('0 cols - HR', 'hollow-rectangle', [0, 1], '');
  testGeneratePattern('1 cols - HR', 'hollow-rectangle', [1, 0], '');
  testGeneratePattern('1 col, 1 row - HR', 'hollow-rectangle', [1, 1], '*');
  testGeneratePattern('1 column - HR', 'hollow-rectangle', [1, 5], '*\n*\n*\n*\n*');
  testGeneratePattern('5 column - HR', 'hollow-rectangle', [5, 1], '*****');
  testGeneratePattern('no hollow rows', 'hollow-rectangle', [6, 2], '******\n******');

  testGeneratePattern("One Dimensional rectangel", "hollow-rectangle", [1, 1], "*");
  testGeneratePattern("Two Dimensional rectangel with 2 rows", "hollow-rectangle", [2, 2], "**\n**");
  testGeneratePattern("Two Dimensional  square rectangel", "hollow-rectangle", [3, 3], "***\n* *\n***");
  testGeneratePattern("Empty columns", "hollow-rectangle", [0, 3], "");

  testGeneratePattern('3 rows', "space-alternating-rectangle", [3, 4], '***\n---\n   \n***');
  testGeneratePattern('3 rows - RAtriangle', "right-aligned-triangle", [3], '  *\n **\n***');
  testGeneratePattern('1 rows - RAtriangle', "right-aligned-triangle", [1], '*');
  testGeneratePattern('0 rows - RAtriangle', "right-aligned-triangle", [0], '');

  console.log("\n");
}

testAll();