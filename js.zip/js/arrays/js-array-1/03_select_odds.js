// Given an array of numbers return a new array containing only odd elements of the
// original array.
// selectOdds([3, 2, 4, 5, 7]) => [3, 5, 7]
// selectOdds([2, 4, 6]) => []
// Do not modify the input array.
function isOdd(number) {
  return number % 2 === 1;
}

function selectOdds(numbers) {
  const oddNumbers = [];  

  for (let index = 0; index < numbers.length; index++) {    
    if(isOdd(numbers[index])) {
      oddNumbers.push(numbers[index]);
    }
  }  
  return oddNumbers;
}

function areItemsEqual(array1, array2) {
  for (let index = 0; index < array1.length; index++) {
    if (array1[index] !== array2[index]) {
      return false;
    }
  }
  return true;
}

function isLengthEqual(array1, array2) {
  return array1.length === array2.length;
}

function areEqual(array1, array2) {
  return isLengthEqual(array1, array2) && areItemsEqual(array1, array2);
}

function details(numbers, expected, actual) {
  const inputMessage = `numbers: [${numbers}] \n`;
  const resultMessage = `expected: ${expected}\nactual: ${actual}`;
  return `${inputMessage}${resultMessage}`;
}

function composeMessage(numbers, expected, actual, description) {
  const isPassed = areEqual(expected, actual);
  const symbol = isPassed ? '✅' : '❌';
  const message = symbol + description + '\n';
  const testDetails = isPassed ? '' : details(numbers, expected, actual);

  return message + testDetails;
}

function testSelectOdds(description, numbers, expected) {  
  const actual = selectOdds(numbers);

  console.log(composeMessage(numbers, expected, actual, description));
}

function testAll() {
  testSelectOdds('contain odd numbers', [1, 2, 3], [1, 3]);
  testSelectOdds('does not contain odd numbers', [6, 72, 8, 10], []);
  testSelectOdds('no numbers', [], []);
};

testAll();