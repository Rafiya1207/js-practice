// Given an array and a value, returns true if the value is present in the array, else false.
// Examples:
// includes([1, 2, 3], 2) => true
// includes([1, 2, 3], 4) => false
// includes([], 1) => false
// do not modify input parameters
function isArray(array) {
  return typeof array === 'object';
}

function areArraysEqual(array1, array2) {
  if (array1.length !== array2.length) {
    return false;
  }

  for (let index = 0; index < array1.length; index++) {
    if (!areDeepEqual(array1[index], array2[index])) {
      return false;
    }
  }

  return true;
}

function areDeepEqual(array1, array2) {
  if (isArray(array1) !== isArray(array2)) {
    return false;
  }

  if (isArray(array1) && isArray(array2)) {
    return areArraysEqual(array1, array2);
  }

  return array1 === array2;
}

function includes(array, target) {
  for (let index = 0; index < array.length; index++) {
    if (areDeepEqual(target, array[index])) {
      return true;
    }
  }
  return false;
}

function details(array, target, expected, actual) {
  const inputMessage = `array: [${array}], target: ${target} \n`;
  const resultMessage = `expected: ${expected}\nactual: ${actual}`;
  return `${inputMessage}${resultMessage}`;
}

function composeMessage(array, target, expected, actual, description) {
  const isPass = expected === actual;
  const symbol = isPass ? '✅' : '❌';
  const message = symbol + description + '\n';
  const testDetails = isPass ? '' : details(array, target, expected, actual);

  return message + testDetails;
}

function testIncludes(description, array, target, expected) {
  const actual = includes(array, target);

  console.log(composeMessage(array, target, expected, actual, description));
}

function testAll() {
  testIncludes('target is present', [1, 2, 3], 2, true);
  testIncludes('target is not present', [1, 2, 3], 8, false);
  testIncludes('array is empty', [], 8, false);
  testIncludes('target is array', [1, 2, [3]], [3], true);
  testIncludes('target is array', [1, 2, [3], 8], [3], true);
  testIncludes('target is nested array', [1, 2, [3, [1]], 8], [3, [1]], true);
  testIncludes('target is string', ['a', 'abc', 'b'], 'abc', true);
}

testAll();