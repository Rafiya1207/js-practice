// Given an array of numbers and a element, return the first index in the array
// where element is present else -1
// findIndex(["apple", "cake", "tea", "coffee", "tea"], "tea") => 2
// do not modify input parameters
function findIndex(array, element) {
  for (let index = 0; index < array.length; index++) {
    if (array[index] === element) {
      return index;
    }
  }
  return -1;
}

function details(array, element, expected, actual) {
  const inputMessage = `array: [${array}], element: [${element}] \n`;
  const resultMessage = `expected: ${expected}\nactual: ${actual}`;
  return `${inputMessage}${resultMessage}`;
}

function composeMessage(array, element, expected, actual, description) {
  const isPassed = expected === actual;
  const symbol = isPassed ? '✅' : '❌';
  const message = symbol + description + '\n';
  const testDetails = isPassed ? '' : details(array, element, expected, actual);

  return message + testDetails;
}

function testFindIndex(description, array, element, expected) {
  const actual = findIndex(array, element);

  console.log(composeMessage(array, element, expected, actual, description));
}

function testAll() {
  testFindIndex('element is at 1', ['apple', 'ball'], 'ball', 1);
  testFindIndex('2 similar elements', ['apple', 'ball', 'ball'], 'ball', 1);
  testFindIndex('elements is not present', ['apple', 'ball', 'ball'], 'bat', -1);
}

testAll();