// Given an array of numbers and a threshold value, return a new array
// that contains all the numbers which are below threshold.
// filterBelow([6, 2, 3, 1, 4, 7], 3) => [2, 1]
// filterBelow([1, 2, 3], 0) => []
// do not modify input parameters
function filterBelow(array, threshold) {
  const filteredArray = [];
  
  for (let index = 0; index < array.length; index++) {
    if (array[index] < threshold) {
      filteredArray.push(array[index]);
    }
  }
  return filteredArray;
}


function areItemsEqual(array1, array2) {
  for (let index = 0; index < array1.length; index++) {
    if (array1[index] !== array2[index]) {
      return false;
    }
  }
  return true;
}

function isLengthEqual(array1, array2) {
  return array1.length === array2.length;
}

function areEqual(array1, array2) {
  return isLengthEqual(array1, array2) && areItemsEqual(array1, array2);
}

function details(array, threshold, expected, actual) {
  const inputMessage = `array: [${array}], threshold: [${threshold}] \n`;
  const resultMessage = `expected: ${expected}\nactual: ${actual}`;
  return `${inputMessage}${resultMessage}`;
}

function composeMessage(array, threshold, expected, actual, description) {
  const isPassed = areEqual(expected, actual);
  const symbol = isPassed ? '✅' : '❌';
  const message = symbol + description + '\n';
  const testDetails = isPassed ? '' : details(array, threshold, expected, actual);

  return message + testDetails;
}

function testFilterBelow(description, array, threshold, expected) {
  const actual = filterBelow(array, threshold);

  console.log(composeMessage(array, threshold, expected, actual, description));
}

function testAll() {
  testFilterBelow('simple array', [6, 2, 3, 1, 4, 7], 3, [2, 1]);
  testFilterBelow('threshold is present', [1, 3, 5], 0, []);
};

testAll();