// Given a string and a single-character delimiter, returns an array of strings
// obtained by splitting the input string at each occurrence of the delimiter.
// The delimiter must be a single character.
// Examples:
// split("a,b,c", ",") => ["a", "b", "c"]
// split("one:two:three", ":") => ["one", "two", "three"]
// split("hello", ",") => ["hello"]

function split(sentence, delimiter) {
  const splittedItems = [];
  let currentSentence = sentence;
  let delimiterIndex = currentSentence.indexOf(delimiter);
  
  while(delimiterIndex !== -1 && delimiter !== '') {
    splittedItems.push(currentSentence.slice(0, delimiterIndex));
    currentSentence = currentSentence.slice(delimiterIndex + 1);
    delimiterIndex = currentSentence.indexOf(delimiter);
  }
  splittedItems.push(currentSentence);

  return splittedItems;
}

function areItemsEqual(array1, array2) {
  for (let index = 0; index < array1.length; index++) {
    if (array1[index] !== array2[index]) {
      return false;
    }
  }
  return true;
}

function isLengthEqual(array1, array2) {
  return array1.length === array2.length;
}

function areEqual(array1, array2) {
  return isLengthEqual(array1, array2) && areItemsEqual(array1, array2);
}

function details(sentence, delimiter, expected, actual) {
  const inputMessage = `sentence: [${sentence}], delimiter: ${delimiter} \n`;
  const resultMessage = `expected: ${expected}\nactual: ${actual}`;
  return `${inputMessage}${resultMessage}`;
}

function composeMessage(sentence, delimiter, expected, actual, description) {
  const isPass = areEqual(expected, actual);
  const symbol = isPass ? '✅' : '❌';
  const message = symbol + description + '\n';
  const testDetails = isPass ? '' : details(sentence, delimiter, expected, actual);

  return message + testDetails;
}

function testSplit(description, sentence, delimiter, expected) {
  const actual = split(sentence, delimiter);

  console.log(composeMessage(sentence, delimiter, expected, actual, description));
}

function testAll() {
  testSplit('split single characters', 'a,b,c', ',', ['a', 'b', 'c']);
  testSplit('delimiter is not in string', 'abc', ',', ['abc']);
  testSplit('delimiter is empty string', 'abc', '', ['abc']);
  testSplit('string and delimiter are same', ',', ',', ['', '']);
}

testAll();