// Given array1 and array2 returns true if both array are equal else false.
// Examples:
// areEqual([1, 2, 3, 4], [1, 2, 3, 4]) => true
// areEqual([1, 2, 3], [1, 2, 3, 4]) => false
// areEqual([1, 2, 3], [1, 3, 2]) => false
// areEqual([1, [22] 3], [1, [22], 3]) => true
// do not modify input parameters
function areItemsEqual(array1, array2) {
  for (let index = 0; index < array1.length; index++) {
    if (array1[index] !== array2[index]) {
      return false;
    }
  }
  return true;
}

function isLengthEqual(array1, array2) {
  return array1.length === array2.length;
}

function areEqual(array1, array2) {
  return isLengthEqual(array1, array2) && areItemsEqual(array1, array2);
}

function details(array1, array2, expected, actual) {
  const inputMessage = `array1: [${array1}], array2: [${array2}] \n`;
  const resultMessage = `expected: ${expected}\nactual: ${actual}`;
  return `${inputMessage}${resultMessage}`;
}

function composeMessage(array1, array2, expected, actual, description) {
  const isPass = expected === actual;
  const symbol = isPass ? '✅' : '❌';
  const message = symbol + description + '\n';
  const testDetails = isPass ? '' : details(array1, array2, expected, actual);

  return message + testDetails;
}

function testIsLengthEqual(description, array1, array2, expected) {
  const actual = isLengthEqual(array1, array2);

  console.log(composeMessage(array1, array2, expected, actual, description));
}

function testIsLengthEqualAll() {
  testIsLengthEqual('arrays length is 2', [1, 2], [4, 5], true);
  testIsLengthEqual('array1 length is > array2', [1, 3, 5], [4, 5], false);
  testIsLengthEqual('nested arrays', [1, 2, [7, 8]], [1, 2, [67, 23]], true);
  testIsLengthEqual('empty arrays', [], [], true);
};

function testAreItemsEqual(description, array1, array2, expected) {
  const actual = areItemsEqual(array1, array2);

  console.log(composeMessage(array1, array2, expected, actual, description));
}

function testAreItemsEqualAll() {
  testAreItemsEqual('arrays are same', [1, 2], [1, 2], true);
  testAreItemsEqual('arrays are different', [1, 2], [4, 5], false);
};

function testAreEqual(description, array1, array2, expected) {
  const actual = areEqual(array1, array2);

  console.log(composeMessage(array1, array2, expected, actual, description));
}

function testAreEqualAll() {
  testAreEqual('arrays are same', [1, 2, 3, 4], [1, 2, 3, 4], true);
  testAreEqual("array's length is different", [1, 2], [1, 2, 3], false);
  testAreEqual('arrays elements are shuffled', [1, 3, 2], [1, 2, 3], false);
};

function main() {
  testAreEqualAll();
}

main();