// Given an array of numbers and a element, return the last index in the array
// where element is present else -1
// findLastIndex(["apple", "cake", "tea", "coffee", "tea", "pen"], "tea") => 4
// do not modify input parameters
function findLastIndex(array, element) {
  for (let index = array.length; index >= 0; index--) {
    if (array[index] === element) {
      return index;
    }
  }
  return -1;
}

function details(array, element, expected, actual) {
  const inputMessage = `array: [${array}], element: [${element}] \n`;
  const resultMessage = `expected: ${expected}\nactual: ${actual}`;
  return `${inputMessage}${resultMessage}`;
}

function composeMessage(array, element, expected, actual, description) {
  const isPass = expected === actual;
  const symbol = isPass ? '✅' : '❌';
  const message = symbol + description + '\n';
  const testDetails = isPass ? '' : details(array, element, expected, actual);

  return message + testDetails;
}

function testFindLastIndex(description, array, element, expected) {
  const actual = findLastIndex(array, element);

  console.log(composeMessage(array, element, expected, actual, description));
}

function testAll() {
  testFindLastIndex('element is at 1', ['apple', 'ball'], 'ball', 1);
  testFindLastIndex('2 similar elements', ['apple', 'ball', 'ball'], 'ball', 2);
  testFindLastIndex('elements is not present', ['apple', 'ball', 'ball'], 'bat', -1);
}

testAll();