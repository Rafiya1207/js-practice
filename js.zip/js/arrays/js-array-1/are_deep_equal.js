// Given array1 and array2, returns true if both arrays are deeply equal, else false.
// Deep equality means both arrays contain the same elements in the same order,
// including any nested arrays, which must also be deeply equal.
// Examples:
// areDeepEqual([1, 2, 3], [1, 2, 3]) => true
// areDeepEqual([1, [2, 3]], [1, [2, 3]]) => true
// areDeepEqual([1, [2, 3]], [1, [3, 2]]) => false
// areDeepEqual([1, 2], [1, 2, 3]) => false
// areDeepEqual([1, [2, [3]]], [1, [2, [3]]]) => true
// areDeepEqual([1, [2, [3]]], [1, [2, 3]]) => false
// do not modify input parameters

function areTwoObjects(array1, array2) {
  return typeof array1 === 'object' && typeof array2 === 'object';
}

function areItemsEqual(array1, array2) {
  let areEqual = true;

  if (array1.length !== array2.length) {
    return false;
  }

  for (let index = 0; index < array1.length; index++) {
    if (areTwoObjects(array1[index], array2[index])) {
      areEqual = areItemsEqual(array1[index], array2[index]);
      index++;
    }
    
    if (array1[index] !== array2[index]) {
      return false;
    }
  }
  return areEqual;
}

function areDeepEqual(array1, array2) {
  return areTwoObjects(array1, array2) && areItemsEqual(array1, array2);
}

function details(array1, array2, expected, actual) {
  const inputMessage = `array1: [${array1}], array2: [${array2}] \n`;
  const resultMessage = `expected: ${expected}\nactual: ${actual}`;
  return `${inputMessage}${resultMessage}`;
}

function composeMessage(array1, array2, expected, actual, description) {
  const isPass = expected === actual;
  const symbol = isPass ? '✅' : '❌';
  const message = symbol + description + '\n';
  const testDetails = isPass ? '' : details(array1, array2, expected, actual);

  return message + testDetails;
}

function testAreDeepEqual(description, array1, array2, expected) {
  const actual = areDeepEqual(array1, array2);

  console.log(composeMessage(array1, array2, expected, actual, description));
}

function testAll() {
  testAreDeepEqual('arrays are same', [1, 2, 3, 4], [1, 2, 3, 4], true);
  testAreDeepEqual('arrays are same', [1, 2, '3', 4], [1, 2, 3, 4], false);
  testAreDeepEqual('1 Depth', [1, 2, [3, 4]], [1, 2, [3, 4]], true);
  testAreDeepEqual('same arrays - 2 depth', [1, [3, [2]]], [1, [3, [2]]], true);
  testAreDeepEqual('same arrays - 1 depth', [1, [3], 89], [1, [3], 89], true);
  testAreDeepEqual('empty arrays - 1 depth', [1, 9], [1, []], false);
  testAreDeepEqual('shuffled items in inner', [1, [2, 3]], [1, [3, 2]], false);
  testAreDeepEqual('different lengths', [1, 2], [1, 2, 3], false);
  testAreDeepEqual('different nests', [1, [2, [3]]], [1, [2, 3]], false);
  testAreDeepEqual('empty arrays', [], [], true);
  testAreDeepEqual('nested array in different order', [[], [1]], [[1], []], false);
  testAreDeepEqual('nested arrays are same', [[1], 2], [[1], 3], false);
};

testAll();