// Given an array of numbers and a threshold value, return a new array
// that contains all the numbers above the threshold.
// filterAbove([6, 2, 3, 1, 4, 7], 3) => [6, 4, 7]
// filterAbove([1, 2, 3], 4) => []
// do not modify input parameters
function filterAbove(array, threshold) {
  const filteredArray = [];

  for (let index = 0; index < array.length; index++) {
    if (array[index] > threshold) {
      filteredArray.push(array[index]);
    }
  }
  return filteredArray;
}

function areItemsEqual(array1, array2) {
  for (let index = 0; index < array1.length; index++) {
    if (array1[index] !== array2[index]) {
      return false;
    }
  }
  return true;
}

function isLengthEqual(array1, array2) {
  return array1.length === array2.length;
}

function areEqual(array1, array2) {
  return isLengthEqual(array1, array2) && areItemsEqual(array1, array2);
}

function details(array, threshold, expected, actual) {
  const inputMessage = `array: [${array}], threshold: [${threshold}] \n`;
  const resultMessage = `expected: ${expected}\nactual: ${actual}`;
  return `${inputMessage}${resultMessage}`;
}

function composeMessage(array, threshold, expected, actual, description) {
  const isPassed = areEqual(expected, actual);
  const symbol = isPassed ? '✅' : '❌';
  const message = symbol + description + '\n';
  const testDetails = isPassed ? '' : details(array, threshold, expected, actual);

  return message + testDetails;
}

function testFilterAbove(description, array, threshold, expected) {
  const actual = filterAbove(array, threshold);

  console.log(composeMessage(array, threshold, expected, actual, description));
}

function testAll() {
  testFilterAbove('simple array', [6, 2, 3, 1, 4, 7], 3, [6, 4, 7]);
  testFilterAbove('threshold is present', [1, 3, 5], 9, []);
};

testAll();