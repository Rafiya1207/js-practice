// Given an array return reverse of array. DO NOT USE `.reverse()` function
// Write your own implementation of reverse
// reverse([1, 2, 3]) => [3, 2, 1]
// reverse([]) => []
// do not modify input parameters
function reverse(array) {
  const reversedArray = [];

  for (let index = array.length - 1; index >= 0; index --) {
    reversedArray.push(array[index]);
  }
  return reversedArray;
}

function areItemsEqual(array1, array2) {
  for (let index = 0; index < array1.length; index++) {
    if (array1[index] !== array2[index]) {
      return false;
    }
  }
  return true;
}

function isLengthEqual(array1, array2) {
  return array1.length === array2.length;
}

function areEqual(array1, array2) {
  return isLengthEqual(array1, array2) && areItemsEqual(array1, array2);
}

function details(array, expected, actual) {
  const inputMessage = `array: [${array}] \n`;
  const resultMessage = `expected: ${expected}\nactual: ${actual}`;
  return `${inputMessage}${resultMessage}`;
}

function composeMessage(array, expected, actual, description) {
  const isPassed = areEqual(expected, actual);
  const symbol = isPassed ? '✅' : '❌';
  const message = symbol + description + '\n';
  const testDetails = isPassed ? '' : details(array, expected, actual);

  return message + testDetails;
}

function testReverse(description, array, expected) {
  const actual = reverse(array);

  console.log(composeMessage(array, expected, actual, description));
}

function testAll() {
  testReverse('simple array', [1, 2, 3], [3, 2, 1]);
  testReverse('array is empty', [], []);
};

testAll();