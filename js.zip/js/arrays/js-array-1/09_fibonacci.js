// Write a function that gives first n elements of fibonacci in an array
// fibonacci(5) => [0, 1, 1, 2, 3]
// do not modify input parameters
function fibonacci(n) {
  const fibonacciElements = [];
  let currentTerm = 0;
  let nextTerm = 1;

  for (let term = 0; term < n; term++) {
    fibonacciElements.push(currentTerm);
    const futureTerm = nextTerm + currentTerm;
    currentTerm = nextTerm;
    nextTerm = futureTerm;
  }
  return fibonacciElements;
}

function areItemsEqual(array1, array2) {
  for (let index = 0; index < array1.length; index++) {
    if (array1[index] !== array2[index]) {
      return false;
    }
  }
  return true;
}

function isLengthEqual(array1, array2) {
  return array1.length === array2.length;
}

function areEqual(array1, array2) {
  return isLengthEqual(array1, array2) && areItemsEqual(array1, array2);
}

function details(endRange, expected, actual) {
  const inputMessage = `endRange: [${endRange}] \n`;
  const resultMessage = `expected: ${expected}\nactual: ${actual}`;
  return `${inputMessage}${resultMessage}`;
}

function composeMessage(endRange, expected, actual, description) {
  const isPassed = areEqual(expected, actual);
  const symbol = isPassed ? '✅' : '❌';
  const message = symbol + description + '\n';
  const testDetails = isPassed ? '' : details(endRange, expected, actual);

  return message + testDetails;
}

function tesFibonacci(description, endRange, expected) {
  const actual = fibonacci(endRange);

  console.log(composeMessage(endRange, expected, actual, description));
}

function testAll() {
  tesFibonacci('first 5 terms', 5, [0, 1, 1, 2, 3]);
  tesFibonacci('1 term', 1, [0]);
  tesFibonacci('2 terms', 2, [0, 1]);
  tesFibonacci('3 terms', 3, [0, 1, 1]);
  tesFibonacci('4 terms', 4, [0, 1, 1, 2]);
  tesFibonacci('0 terms', 0, []);
};

testAll();