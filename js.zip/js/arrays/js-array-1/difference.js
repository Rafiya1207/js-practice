// Return all the elements of array1 which are not present in array2.
// difference([1, 2, 3], [2, 3, 4]) => [1]
function isArray(array) {
  return typeof array === 'object';
}

function areArraysEqual(array1, array2) {
  if (array1.length !== array2.length) {
    return false;
  }

  for (let index = 0; index < array1.length; index++) {
    if (!areDeepEqual(array1[index], array2[index])) {
      return false;
    }
  }

  return true;
}

function areDeepEqual(array1, array2) {
  if (isArray(array1) !== isArray(array2)) {
    return false;
  }

  if (isArray(array1) && isArray(array2)) {
    return areArraysEqual(array1, array2);
  }

  return array1 === array2;
}

function includes(array, target) {
  for (let index = 0; index < array.length; index++) {
    if (areDeepEqual(target, array[index])) {
      return true;
    }
  }
  return false;
}

function difference(array1, array2) {
  const differenceElements = [];

  for (let index = 0; index < array1.length; index++) {
    if (!includes(array2, array1[index])) {
      differenceElements.push(array1[index]);
    }
  }
  return differenceElements;
}

function details(array1, array2, expected, actual) {
  const inputMessage = `array1: [${array1}], array2: [${array2}] \n`;
  const resultMessage = `expected: ${expected}\nactual: ${actual}`;
  return `${inputMessage}${resultMessage}`;
}

function composeMessage(array1, array2, expected, actual, description) {
  const isPass = areDeepEqual(expected, actual);
  const symbol = isPass ? '✅' : '❌';
  const message = symbol + description + '\n';
  const testDetails = isPass ? '' : details(array1, array2, expected, actual);

  return message + testDetails;
}

function testDifference(description, array1, array2, expected) {
  const actual = difference(array1, array2);

  console.log(composeMessage(array1, array2, expected, actual, description));
}

function testAll() {
  testDifference('difference is one element', [1, 2, 3], [2, 3, 4], [1]);
  testDifference('no element is present', [4, 2, 3], [2, 3, 4], []);
};

testAll();