function padWithZero(data, padSize = 2) {
  const string = "" + data;
  return string.padStart(padSize, "0");
}

function isLeapYear(year) {
  if (year === 0) {
    return false;
  }
  const isDivisibleBy400 = year % 400 === 0;
  const isDivisibleBy4 = year % 4 === 0;
  const isDivisibleBy100 = year % 100 === 0;
  return isDivisibleBy400 || (isDivisibleBy4 && !isDivisibleBy100);
}

function lastDayOfTheMonth(month, year) {
  switch (month) {
    case 2:
      return isLeapYear(year) ? 29 : 28;
    case 4:
    case 6:
    case 9:
    case 11:
      return 30;
    default:
      return 31;
  }
}

function yearIncrement(day, month, year) {
  if (day === 31 && month === 12) {
    return padWithZero(year + 1, 4);
  }
  return padWithZero(year, 4);
}

function monthIncement(day, month, year) {
  if (month === 12) {
    return padWithZero(1);
  }

  if (day === lastDayOfTheMonth(month, year)) {
    return padWithZero(month + 1);
  }
  return padWithZero(month);
}

function dayIncrement(day, month, year) {
  if (day === lastDayOfTheMonth(month, year)) {
    return padWithZero(1);
  }
  return padWithZero(day + 1);
}

function dateIncrement(day, month, year) {
  const incrementedDay = dayIncrement(day, month, year);
  const incrementMonth = monthIncement(day, month, year);
  const incrementYear = yearIncrement(day, month, year);
  if (!checkIfValidDate(incrementedDay, incrementMonth, incrementYear)) {
    return "Invalid Date";
  }
  return `${incrementedDay}-${incrementMonth}-${incrementYear}`;
}

function isYearValid(year) {
  return (year >= 0) && year < 10000;
}

function isMonthValid(month) {
  return month > 0 && (month <= 12);
}

function isDateValid(day, month, year) {
  return day > 0 && (day <= lastDayOfTheMonth(month, year));
}

function checkIfValidDate(day, month, year) {
  return isDateValid(day, month, year) && isMonthValid(month) && isYearValid(year);
}

function nextDate(date) {
  const day = parseInt(date.slice(0, 2));
  const month = parseInt(date.slice(3, 5));
  const year = parseInt(date.slice(6, 10));
  if (!checkIfValidDate(day, month, year)) {
    return "Invalid Date";
  }

  return dateIncrement(day, month, year);
}

function composeResult(result, details, actual, expected) {
  let finalresult = "Test " + result;
  finalresult +=  `${details}`;
  if (result === "❌") {
    finalresult += " \n\t| expected  = " + expected;
    finalresult += " \n\t| actual  = " + actual;
  }
  return finalresult;
}

function testNextDate(details, date, expected) {
  const actual = nextDate(date);
  const result = actual === expected ? "✅" : "❌";
  const finalResult = composeResult(result, details, actual, expected);
  console.log(finalResult);
}

function testNextMonthCondition() {
  testNextDate("Next month 31 days", "31-01-2025", "01-02-2025");
  testNextDate("Next month 30 days", "31-10-2025", "01-11-2025");
  testNextDate("Next month for feb (normal)", "28-02-2023", "01-03-2023");
  testNextDate("Next month for feb (leap year)", "29-02-2024", "01-03-2024");
}

function testZeroCases() {
  testNextDate("0th month condition", "32-00-2025", "Invalid Date");
  testNextDate("0th day condition", "00-01-2025", "Invalid Date");
  testNextDate("0th year condition", "01-01-0000", "02-01-0000");
}

function testGeneralConditions() {
  testNextDate("Simple day increment", "01-01-2025", "02-01-2025");

  testNextDate("Last day of Feb in Leap Year", "28-02-2024", "29-02-2024");
  testNextDate("New Year", "31-12-2025", "01-01-2026");

  testNextDate("More than 31 days", "32-01-2025", "Invalid Date");
  testNextDate("29th day of Feb (normal year)", "30-02-2023", "Invalid Date");
  testNextDate("31st day of 30 day month", "31-11-0000", "Invalid Date");

  testNextDate("End of time", "31-12-9999", "Invalid Date");
  testNextDate("Start of time leap year", "29-02-0000", "Invalid Date");
  testNextDate("13th month", "31-13-0000", "Invalid Date");
}

function main() {
  testGeneralConditions();
  testNextMonthCondition();
  testZeroCases();
}

main();