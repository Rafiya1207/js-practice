function isDivisble(dividend, divisor) {
  return dividend % divisor === 0;
}

function isLeapYear(year) {
  const isDivibleBy4 = isDivisble(year, 4);
  const isDivibleBy400 = isDivisble(year, 400);
  const isNotDivibleBy100 = !isDivisble(year, 100);
  const isYear0 = year === 0;
  
  return (!isYear0 && isDivibleBy4 && (isDivibleBy400 || isNotDivibleBy100));
}

function daysInAMonth(month, year) {
  switch (month) {
    case 2: return isLeapYear(year) ? 29 : 28;
    case 4:;
    case 6:;
    case 9:;
    case 11: return 30;
    default: return 31;
  }
}

function toPaddedString(number, length) {
  return ('' + number).padStart(length, '0');
}

function formatDate(day, month, year) {
  const nextDay = toPaddedString(day, 2);
  const paddedMonth = toPaddedString(month, 2);
  const paddedYear = toPaddedString(year, 4);

  return `${nextDay}-${paddedMonth}-${paddedYear}`;
}

function isLastDayOfMonth(day, month, year) {
  return day === daysInAMonth(month, year);
}

function isLastDayOfYear(day, month) {
  return day === 31 && month === 12;
}

function incrementDay(day, month, year) {
  if (isLastDayOfYear(day, month)) {
    return formatDate(1, 1, year + 1);
  }

  if (isLastDayOfMonth(day, month, year)) {
    return formatDate(1, month + 1, year);
  }
  return formatDate(day + 1, month, year);
}

function isInvalidDay(day, month, year) {
  return day <= 0 || day > daysInAMonth(month, year);
}

function isInvalidYear(year) {
  return year < 0 || year > 9999;
}

function isInvalidDate(day, month, year) {
  const isInvalidMonth = month < 1 || month > 12;

  return isInvalidDay(day, month, year) || isInvalidYear(year) || isInvalidMonth;
}

function nextDate(date) {
  const day = parseInt(date.slice(0, 2));
  const month = parseInt(date.slice(3, 5));
  const year = parseInt(date.slice(6, 10));

  if (isInvalidDate(day, month, year)) {
    return 'Invalid Date';
  }

  return incrementDay(day, month, year);
}

function details(date, expected, actual) {
  const inputMessage = `date: [${date}] \n`;
  const resultMessage = `expected: ${expected}\nactual: ${actual}`;
  return `${inputMessage}${resultMessage}`;
}

function composeMessage(date, expected, actual, description) {
  const isPassed = expected === actual;
  const symbol = isPassed ? '✅' : '❌';
  const message = symbol + description + '\n';
  const testDetails = isPassed ? '' : details(date, expected, actual);
  
  return message + testDetails;
}

function testNextDate(description, date, expected) {
  const actual = nextDate(date);

  console.log(composeMessage(date, expected, actual, description));
}

function testAll() {
  testNextDate('increment of a normal day', '15-03-2021', '16-03-2021');
  testNextDate('30th august', '30-08-2021', '31-08-2021');
  testNextDate('30th september', '30-09-2021', '01-10-2021');
  testNextDate('last day of an year', '31-12-2021', '01-01-2022');
  testNextDate('28th feb in non leap year', '28-02-2021', '01-03-2021');
  testNextDate('28th feb in leap year', '28-02-2024', '29-02-2024');
  testNextDate('29th feb in leap year', '29-02-2024', '01-03-2024');
  testNextDate('a day of century year', '28-02-0100', '01-03-0100');
  testNextDate('last day of 999 year', '31-12-0999', '01-01-1000');
  testNextDate('last day of 0 year', '31-12-0000', '01-01-0001');
  testNextDate('normal day of 0 year', '02-12-0000', '03-12-0000');
  testNextDate('a day with month exceeding 12', '01-44-2021', 'Invalid Date');
  testNextDate('a day exceeding 31 ', '41-04-2000', 'Invalid Date');
  testNextDate('a day less than 1', '00-04-2000', 'Invalid Date');
  testNextDate('last day which is not in month', '31-04-2021', 'Invalid Date');
  testNextDate('a day which is not in month', '32-02-2021', 'Invalid Date');
  testNextDate('29th feb in non leap year', '29-02-2021', 'Invalid Date');
  testNextDate('29th feb in 0 year', '29-02-0000', 'Invalid Date');
  testNextDate('28th feb in 0 year', '28-02-0000', '01-03-0000');
}

testAll();