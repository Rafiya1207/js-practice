checkIfValidDate can be shortened
'!' can also be changed before it
extra parenthesis in line 66, 70, 74

why checking validity again in dateIncrement

rather dayIncrement for function it would be better if you start function name with verb 'increment', which sounds you're telling/commanding the function to do something

why incrementing month again if you've already incremented the day

what is string? it is not stating the data it is containing. 

what is data? isn't it too genereic.

I'm not sure about padSize but I think I guess It doesn't fit.
