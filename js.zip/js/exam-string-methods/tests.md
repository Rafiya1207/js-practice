| Description | Input | Output |
| --- | --- | --- |
| Simple increment of a normal day | 15-03-2021 | 16-03-2021 |
| Increment of 30th day of august | 30-08-2021 | 31-08-2021 |
| Increment of 30th day of september | 30-09-2021 | 01-10-2021 |
| Increment of 28th day of other months except feb in non leap year | 28-04-2021 | 29-04-2021 |
| Increment of 29th day of other months except feb in leap year | 29-04-2021 | 30-04-2021 |
| Increment of a last day of a month | 30-11-2021 | 01-12-2021 |
| Increment of a last day of the year | 31-12-2021 | 01-01-2022 |
| Increment of a last day of a month with 31 days | 31-01-2021 | 01-02-2021 |
| Increment of a last day of a month with 30 days | 30-10-2021 | 01-11-2021 |
| Increment of a last day of feb in non leap year | 28-02-2005 | 01-03-2005 |
| Increment of a last day of feb in leap year | 29-02-2004 | 01-03-2004 |
| Increment of a 28th day of feb in leap year | 28-02-2004 | 29-02-2004 |
| Increment of a 29th day of feb in non leap year  | 29-02-2021 | "Invalid Date" |
| Increment of a day which is not part of the month | 31-04-2021 | "Invalid Date" |
| Increment of a day with moth exceeding 12 | 01-44-2021 | "Invalid Date" |
| Increment of a day with year less than 999 | 01-04-0000 | "Invalid Date" |
| Increment of a day exceeding 31 | 41-04-2000 | "Invalid Date" |
| Increment of a day less than 0 | 00-04-2000 | "Invalid Date" |
| | | |