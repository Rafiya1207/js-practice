let numberOfTimes = 0;

function sort(data) {
  const sortedData = data.slice();

  for (let i = 0; i < sortedData.length; i++) {
    for (let j = i + 1; j < sortedData.length; j++) {
      numberOfTimes++;
      if (sortedData[j] < sortedData[i]) {
        const temp = sortedData[i];
        sortedData[i] = sortedData[j];
        sortedData[j] = temp;
      }
    }
  }
  return sortedData;
}

function medianOf(data) {
  const sortedData = sort(data);
  return sortedData[Math.floor(data.length/2)];
}

function meanOf(data) {
  let sum = 0;

  for (let index = 0; index < data.length; index++) {
    sum += data[index];
  }

  return sum / data.length;
}

function standardDeviation(data) {
  const mean = meanOf(data);
  let sumOfSquares = 0;

  for (let index = 0; index < data.length; index++) {
    sumOfSquares += (mean - data[index]) ** 2;
  }
  
  return Math.sqrt(sumOfSquares) / data.length;
}

function generateNumber(lower, upper) {
  return lower + Math.floor(Math.random() * (upper - lower));
}

function genrateData(length) {
  const data = [];

  for (let i = 0; i < length; i++) {
    data.push(generateNumber(1, 100));
  }
  return data;
}

function benchmark(length) {
  numberOfTimes = 0;
  const data = genrateData(length);
  const median = medianOf(data);
  const mean = meanOf(data);
  const deviation = standardDeviation(data);

  const difference = Math.abs(median - mean)

  let message = '-'.repeat(20);
  message += `\n${length} | ${numberOfTimes} \n`;
  message +=  `data: ${data} \n`;
  message +=  `median: ${median} \n`;
  message +=  `mean: ${mean} \n`;
  // message +=  `close: ${difference} \n`;
  message +=  `standard deviation: ${deviation} \n`;

  console.log(message);
}

function main() {
  for (let times = 1; times < 10; times++) {
    benchmark(times);
  }
}

function test() {
  const data = [5, 8, 9, 2, 3, 1];
  const std = standardDeviation(data);
  const mean = meanOf(data);
  console.log(mean);
  console.log(std);
  
}
// test()
main()