// Do not rename a or b, use them as input for your program.
// While testing we will change their values.

const a = 0;
const b = 1;

// Print the HCF of a and b
// Printing more than one output or printing anything other than HCF might will be consider as error.

// START YOUR CODE AFTER THIS LINE. DO NOT REMOVE THIS LINE
let factor = (a < b) ? a : b;
let hcf = 1;
let hasHcfNotFound = true;

while (hasHcfNotFound && factor > 0) {
  if (a % factor === 0 && b % factor === 0) {
    hcf = factor;
    hasHcfNotFound = false;
  }
  factor--;
}

console.log(hcf);