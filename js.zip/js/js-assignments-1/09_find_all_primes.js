// Do not rename startOfRange or endOfRange, use them as input for your program.
// While testing we will change their values.

const startOfRange = 0;
const endOfRange = 1;

// Print all prime numbers between startOfRange and endOfRange(both inclusive).
// For example, if startOfRange = 5 and endOfRange = 13, then the output should be
// 5
// 7
// 11
// 13
// START YOUR CODE AFTER THIS LINE. DO NOT REMOVE THIS LINE

for (let currentNumber = startOfRange; currentNumber <= endOfRange; currentNumber++) {
  let isPrime = true;

  for (let divisor = 2; divisor < currentNumber; divisor++) {
    if (currentNumber % divisor === 0) {
      isPrime = false;
    }    
  }

  if(isPrime && currentNumber > 1) {
    console.log(currentNumber);
  }
}