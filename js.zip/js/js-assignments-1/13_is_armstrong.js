// Do not rename a use it as input for your program.
// While testing we will change its values.

const a = 0;

// Print true if a is an armstrong number otherwise print false
// A number is called Armstrong number if it is equal to the sum of the cubes of its own digits.
// For example: 153 is an Armstrong number since 153 = 1^3 + 5^3 + 3^3.
// Printing more than one output or printing anything other than armstrong or not armstrong might will be consider as error.

// START YOUR CODE AFTER THIS LINE. DO NOT REMOVE THIS LINE

const noOfDigits = (a + "").length;
let sum = 0;
let quotient = a;

while (quotient > 0) {
  const lastDigit = quotient % 10;
  quotient = (quotient - lastDigit) / 10;
  sum = sum + lastDigit ** noOfDigits;
}

const isArmstrongNumber = (a === sum);
console.log(isArmstrongNumber);