// Do not rename a, use them as input for your program.
// While testing we will change its values.

const a = 121;

// Print true if a is palindrome otherwise print false
// Printing more than one output or printing anything other than palindrome or not palindrome might will be consider as error.
// START YOUR CODE AFTER THIS LINE. DO NOT REMOVE THIS LINE
let reversedNumber = 0;
let quotient = a;

while (quotient > 0) {
  const lastDigit = quotient % 10;
  quotient = (quotient - lastDigit) / 10;
  reversedNumber = reversedNumber * 10 + lastDigit;
}

const isPalindrome = (reversedNumber === a);
console.log(isPalindrome);