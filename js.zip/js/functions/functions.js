function add(a, b) {
  return a + b;
}

const calculate = function (a, ) {
  
}

console.log(add);