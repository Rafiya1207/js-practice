function removeLastChar(string, index) {
  if (index === string.length - 1) {
    return '';
  }
  return string[index] + removeLastChar(string, index + 1);
}

function reverse(string) {
  if (string === '') {
    return '';
  }
  const lastChar = string[string.length - 1];

  return lastChar + reverse(removeLastChar(string, 0));

}

function detailedMessage(string, expected, actual, description) {
  const inputMessage = ' input: [' + string + ']\n';
  const resultMessage = ' expected: ' + expected + '\n actual ' + actual;
  return '❌' + description + '\n' + inputMessage + resultMessage;
}

function composeMessage(string, expected, actual, description) {
  if (expected === actual) {
    return '✅' + description;
  }
  return detailedMessage(string, expected, actual, description);
}

function testReverse(string, expected, description) {
  const actual = reverse(string);

  console.log(composeMessage(string, expected, actual, description));
}

function testAll() {
  testReverse('a', 'a', 'single character');
  testReverse('ab', 'ba', 'string has two characters');
  testReverse('hello', 'olleh', 'string is word');
  testReverse('hello world', 'dlrow olleh', 'string with a space');
  testReverse('  ', '  ', 'string with spaces');
}

testAll();