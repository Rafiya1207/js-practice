function hasFactor(integer, factor) {
  if (integer === factor) {
    return true;
  }
  if (integer % factor === 0) {
    return false;
  }
  return hasFactor(integer, factor + 1);
}

function isPrime(primeCandidate) {
  if (primeCandidate <= 1) {
    return false;
  }
  return hasFactor(primeCandidate, 2);
}

function detailedMessage(primeCandidate, expected, actual, description) {
  const inputMessage = ' input: [' + primeCandidate + ']\n';
  const resultMessage = ' expected: ' + expected + '\n actual ' + actual;
  return '❌' + description + '\n' + inputMessage + resultMessage;
}

function composeMessage(primeCandidate, expected, actual, description) {
  if (expected === actual) {
    return '✅' + description;
  }
  return detailedMessage(primeCandidate, expected, actual, description);
}

function testIsPrime(primeCandidate, expected, description) {
  const actual = isPrime(primeCandidate);

  console.log(composeMessage(primeCandidate, expected, actual, description));
}

function testAll() {
  testIsPrime(2, true, 'prime candidate is 2');
  testIsPrime(3, true, 'prime candidate is 3');
  testIsPrime(5, true, 'prime candidate is 5');
  testIsPrime(4, false, 'prime candidate is even');
  testIsPrime(9, false, 'prime candidate is divisible by 3');
  testIsPrime(0, false, 'prime candidate is less than 1');
  testIsPrime(1, false, 'prime candidate is 1');
}

testAll();