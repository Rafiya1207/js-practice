function isInString(string, otherString, subStringIndex, index) {
  if (subStringIndex === otherString.length) { 
    return true;
  }
  if (index === string.length) {
    return false;
  }
  if (string[index] === otherString[subStringIndex]) {
    subStringIndex = subStringIndex + 1;
  }
  return isInString(string, otherString, subStringIndex, index + 1);
}

function isSubString(string, otherString) {
  if (otherString.length === 0) {
    return false;
  }
  return isInString(string, otherString, 0, 0);
}

function detailedMessage(string, otherString, expected, actual, description) {
  const inputMessage = ` input: [${string}, ${otherString}]\n`;
  const resultMessage = ' expected: ' + expected + '\n actual ' + actual;

  return '❌' + description + '\n' + inputMessage + resultMessage;
}

function composeMessage(string, otherString, expected, actual, description) {
  if (expected === actual) {
    return '✅' + description;
  }
  return detailedMessage(string, otherString, expected, actual, description);
}

function testIsSubString(string, subString, expected, description) {
  const actual = isSubString(string, subString);

  console.log(composeMessage(string, subString, expected, actual, description));
}

function testAll() {
  testIsSubString('a', 'a', true, 'substring character is same as string');
  testIsSubString('ab', 'a', true, 'substring at 1st position');
  testIsSubString('ab', 'b', true, 'substring at 2nd position');
  testIsSubString('abc', 'ab', true, 'substring has more than one character');
  testIsSubString('abc', 'bc', true, 'substring is after first character');
  testIsSubString('abcdef', 'cd', true, 'substring in between');
  testIsSubString('abcdef', 'k', false, 'not a substring');
  testIsSubString('abcdef', '', false, 'empty substring');
}

testAll();