function lastIndex(string, char, index) {
  if (string[index] === char) { 
    return index;
  }

  if (index === 0) { 
    return -1;
  }
  return lastIndex(string, char, index - 1);
}

function findLastIndex(string, char) {
  if (string.length === 0) {
    return -1;
  }
  return lastIndex(string, char, string.length - 1);
}

function detailedMessage(string, char, expected, actual, description) {
  const inputMessage = ` input: [${string}, ${char}]\n`;
  const resultMessage = ' expected: ' + expected + '\n actual ' + actual;
  return '❌' + description + '\n' + inputMessage + resultMessage;
}

function composeMessage(string, char, expected, actual, description) {
  if (expected === actual) {
    return '✅' + description;
  }
  return detailedMessage(string, char, expected, actual, description);
}

function testFindLastIndex(string, char, expected, description) {
  const actual = findLastIndex(string, char);

  console.log(composeMessage(string, char, expected, actual, description));
}

function testAll() {
  testFindLastIndex('ab', 'a', 0, 'character is at first position');
  testFindLastIndex('ab', 'b', 1, 'string one character');
  testFindLastIndex('hello', 'l', 3, 'string has one more than given char');
  testFindLastIndex('hello', '', -1, 'string has one more than given char');
  testFindLastIndex('hello', 'k', -1, 'string has one more than given char');
  testFindLastIndex('llll', 'l', 3, 'string has one more than given char');
  testFindLastIndex('hello', '', -1, 'char is empty string');
  testFindLastIndex('', 'e', -1, 'string is empty');
  testFindLastIndex('  ', ' ', 1, 'char is space');
}

testAll();