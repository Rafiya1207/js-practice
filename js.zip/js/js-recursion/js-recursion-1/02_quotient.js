function quotient(dividend, divisor) {
  if (dividend < divisor) {
    return 0;
  }
  return quotient(dividend - divisor, divisor) + 1;
}

function composeMessage(dividend, divisor, expectedResult, actualResult) {
  const resultCharacter = expectedResult === actualResult ? "✅" : "❌";
  const inputMessage = " [" + dividend + ',' + divisor + "]";
  const resultMessage = " | " + expectedResult + " | " + actualResult;

  return resultCharacter + inputMessage + resultMessage;
}

function testQuotient(dividend, divisor, expectedResult) {
  const actualResult = quotient(dividend, divisor);

  console.log(composeMessage(dividend, divisor, expectedResult, actualResult));
}

function testAll() {
  testQuotient(3, 1, 3);
  testQuotient(15, 3, 5);
  testQuotient(3, 3, 1);
  testQuotient(16, 2, 8);
  testQuotient(3, 2, 1);
  testQuotient(0, 2, 0);
  testQuotient(14, 4, 3);
  testQuotient(21, 5, 4);
}

testAll();