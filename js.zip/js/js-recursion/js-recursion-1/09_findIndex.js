function findFirstIndex(string, char, index) {
  if (index === string.length) {
    return -1;
  }

  if (string[index] === char) {
    return index;
  }

  return findFirstIndex(string, char, index + 1);
}

function findIndex(string, char) {
  return findFirstIndex(string, char, 0);
}

function detailedMessage(string, char, expected, actual, description) {
  const inputMessage = ` input: [${string}, ${char}]\n`;
  const resultMessage = ' expected: ' + expected + '\n actual ' + actual;
  return '❌' + description + '\n' + inputMessage + resultMessage;
}

function composeMessage(string, char, expected, actual, description) {
  if (expected === actual) {
    return '✅' + description;
  }
  return detailedMessage(string, char, expected, actual, description);
}

function testFindIndex(string, char, expected, description) {
  const actual = findIndex(string, char);

  console.log(composeMessage(string, char, expected, actual, description));
}

function testAll() {
  testFindIndex('ab', 'a', 0, 'character is at first position');
  testFindIndex('ab', 'b', 1, 'character is at second position');
  testFindIndex('hello', 'l', 2, 'string has one more than given char');
  testFindIndex('hello', '', -1, 'char is empty string');
  testFindIndex('', 'e', -1, 'string is empty');
  testFindIndex('', '', -1, 'string is empty');
  testFindIndex('  ', ' ', 0, 'char is space');
  testFindIndex('hello', 'o', 4, 'char is last character');
  testFindIndex('hello', 'h', 0, 'char is last character');
  testFindIndex('hello', 'e', 1, 'char is last character');
  testFindIndex('hello', 'k', -1, 'char is last character');
}

testAll();