function remainder(dividend, divisor) {
  if (dividend < divisor) {
    return dividend;
  }
  
  return remainder(dividend - divisor, divisor);
}

function composeMessage(dividend, divisor, expectedResult, actualResult) {
  const resultCharacter = expectedResult === actualResult ? "✅" : "❌";
  const inputMessage = " [" + dividend + ',' + divisor + "]";
  const resultMessage = " | " + expectedResult + " | " + actualResult;

  return resultCharacter + inputMessage + resultMessage;
}

function testRemainder(dividend, divisor, expectedResult) {
  const actualResult = remainder(dividend, divisor);

  console.log(composeMessage(dividend, divisor, expectedResult, actualResult));
}

function testAll() {
  testRemainder(3, 1, 0);
  testRemainder(3, 2, 1);
  testRemainder(3, 3, 0);
  testRemainder(5, 3, 2);
  testRemainder(7, 3, 1);
  testRemainder(1, 3, 1);
  testRemainder(0, 3, 0);
}

testAll();