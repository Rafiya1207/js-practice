function hasFactor(integer, factor) {
  if (integer === factor) {
    return true;
  }
  if (integer % factor === 0) {
    return false;
  }
  return hasFactor(integer, factor + 1);
}

function isPrime(primeCandidate) {
  return hasFactor(primeCandidate, 2);
}

function firstPrimeAbove(number) {
  if (number <= 1) {
    return 2;
  }
  const nextNumber = number + 1;

  if (isPrime(nextNumber)) {
    return nextNumber;
  }
  return firstPrimeAbove(nextNumber);
}

function detailedMessage(number, expected, actual, description) {
  const inputMessage = ' input: [' + number + ']\n';
  const resultMessage = ' expected: ' + expected + '\n actual ' + actual;

  return '❌' + description + '\n' + inputMessage + resultMessage;
}

function composeMessage(number, expected, actual, description) {
  if (expected === actual) {
    return '✅' + description;
  }
  return detailedMessage(number, expected, actual, description);
}

function testFirstPrimeAbove(number, expected, description) {
  const actual = firstPrimeAbove(number);

  console.log(composeMessage(number, expected, actual, description));
}

function testAll() {
  testFirstPrimeAbove(2, 3, 'number is 2');
  testFirstPrimeAbove(3, 5, 'number is odd');
  testFirstPrimeAbove(8, 11, 'number is even');
  testFirstPrimeAbove(0, 2, 'number is less than 1');
  testFirstPrimeAbove(1, 2, 'number is 1');
  testFirstPrimeAbove(89, 97, 'number is above 50');
  testFirstPrimeAbove(-1, 2, 'number is negative');
}

testAll();