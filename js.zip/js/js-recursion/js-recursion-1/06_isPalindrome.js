function areCharactersSame(string, index) {  
  if (index > string.length / 2) {
    return true;
  }

  if (string[index] !== string[(string.length - 1) - index]) { 
    return false;
  }
  
  return areCharactersSame(string, index + 1);
}

function isPalindrome(palindromeCandidate) {
  if (palindromeCandidate.length <= 1) {
    return true; 
  }
  return areCharactersSame(palindromeCandidate, 0);
}

function detailedMessage(palindromeCandidate, expected, actual, description) {
  const inputMessage = ' input: [' + palindromeCandidate + ']\n';
  const resultMessage = ' expected: ' + expected + '\n actual ' + actual;
  return '❌' + description + '\n' + inputMessage + resultMessage;
}

function composeMessage(palindromeCandidate, expected, actual, description) {
  if (expected === actual) {
    return '✅' + description;
  }
  return detailedMessage(palindromeCandidate, expected, actual, description);
}

function testIsPalindrome(candidate, expected, description) {
  const actual = isPalindrome(candidate);

  console.log(composeMessage(candidate, expected, actual, description));
}

function testAll() {
  testIsPalindrome('a', true, 'single character');
  testIsPalindrome('ab', false, 'two different characters');
  testIsPalindrome('aa', true, 'same two characters');
  testIsPalindrome('mam', true, 'string is palindrome');
  testIsPalindrome('abcd', false, 'string is not palindrome');
  testIsPalindrome('111', true, 'string has numbers');
  testIsPalindrome('', true, 'empty string');
  testIsPalindrome('madam', true, 'string is palindrome');
  testIsPalindrome('maklam', false, 'string is not palindrome');
}

testAll();