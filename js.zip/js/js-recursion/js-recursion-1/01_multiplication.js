function multiply(multiplier, multiplicand) {
  if (multiplier < 0 && multiplicand > 0) {
    multiplicand = multiplicand - multiplicand - multiplicand;
  }

  if (multiplier === 0) {
    return 0;
  }

  return multiply(Math.abs(multiplier) - 1, multiplicand) + multiplicand;
}

function composeMessage(multiplier, multiplicand, expected, actual) {
  const resultCharacter = expected === actual ? "✅" : "❌";
  const inputMessage = " [" + multiplier + ',' + multiplicand + "]";
  const resultMessage = " | " + expected + " | " + actual;

  return resultCharacter + inputMessage + resultMessage;
}

function testMultiply(multiplier, multiplicand, expected) {
  const actual = multiply(multiplier, multiplicand);

  console.log(composeMessage(multiplier, multiplicand, expected, actual));
}

function testAll() {
  testMultiply(5, 3, 15);
  testMultiply(1, 3, 3);
  testMultiply(2, 3, 6);
  testMultiply(0, 3, 0);
  testMultiply(10, 0, 0);
  testMultiply(10, 10, 100);
  testMultiply(2, 10, 20);
  testMultiply(2, -10, -20);
  testMultiply(-2, 10, -20);
  testMultiply(-2, -10, -20);
  testMultiply(10, -1, -10);
  testMultiply(0, 0, 0);
}

testAll();