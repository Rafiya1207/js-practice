function f(x) {
  if (x === 1) return 1;
  return f(x - 1) + f(1) + f(1);
}