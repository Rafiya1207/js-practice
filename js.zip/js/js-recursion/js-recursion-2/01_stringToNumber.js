function strToNumber(string, index, convertedNumber) {
  if (index > string.length - 1) {
    return convertedNumber;
  }
  convertedNumber = (convertedNumber * 10) + (string[index] * 1);
  
  return strToNumber(string, index + 1, convertedNumber);
}

function stringToNumber(string) {
  if (string[0] === '-') {
    return strToNumber(string, 1, 0) * -1;
  }
  return strToNumber(string, 0, 0);
}

function detailedMessage(string, expected, actual, description) {
  const inputMessage = ' input: [' + string + ']\n';
  const resultMessage = ' expected: ' + expected + '\n actual ' + actual;
  return '❌' + description + '\n' + inputMessage + resultMessage;
}

function composeMessage(string, expected, actual, description) {
  if (expected === actual) {
    return '✅' + description;
  }
  return detailedMessage(string, expected, actual, description);
}

function testStringToNumber(description, string, expected) {
  const actual = stringToNumber(string);

  console.log(composeMessage(string, expected, actual, description));
}

function testAll() {
  testStringToNumber("convert '1'", '1', 1);
  testStringToNumber("convert '2'", '2', 2);
  testStringToNumber("convert two digits", '12', 12);
  testStringToNumber("convert three digits", '122', 122);
  testStringToNumber("convert four digits", '5670089', 5670089);
  testStringToNumber("string is 1000", '1000', 1000);
  testStringToNumber("convert zeros", '000', 0);
  testStringToNumber("string has negavtive number", '-1', -1);
  testStringToNumber("negavtive number with leading zero", '-01', -1);
  testStringToNumber("string has leading zero", '0123', 123);
  testStringToNumber("string has leading zeros", '000123', 123);
}

testAll();