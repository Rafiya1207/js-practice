function nthFibonacci(nthTerm, curerntTerm, nextTerm, position) {
  if (position === nthTerm) {
    return curerntTerm;
  }
  return nthFibonacci(nthTerm, nextTerm, curerntTerm + nextTerm, position + 1);
}

function nthFibonacciTerm(nthTerm) {
  return nthFibonacci(nthTerm, 0, 1, 1);
}

function detailedMessage(string, expected, actual, description) {
  const inputMessage = ' input: [' + string + ']\n';
  const resultMessage = ' expected: ' + expected + '\n actual ' + actual;

  return `❌ ${description}\n${inputMessage}${resultMessage}`;
}

function composeMessage(string, expected, actual, description) {
  if (expected === actual) {
    return '✅' + description;
  }
  return detailedMessage(string, expected, actual, description);
}

function testNthFibonacciTerm(description, string, expected) {
  const actual = nthFibonacciTerm(string);

  console.log(composeMessage(string, expected, actual, description));
}

function testAll() {
  testNthFibonacciTerm('first term', 1, 0);
  testNthFibonacciTerm('second term', 2, 1);
  testNthFibonacciTerm('third term', 3, 1);
  testNthFibonacciTerm('fourth term', 4, 2);
  testNthFibonacciTerm('fifth term', 5, 3);
  testNthFibonacciTerm('sixth term', 6, 5);
  testNthFibonacciTerm('tenth term', 10, 34);
}

testAll();