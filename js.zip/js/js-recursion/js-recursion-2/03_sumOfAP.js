function sumOfAPSeries(term, diff, nTerms, currentTerm, sum) {
  if (currentTerm === nTerms) {
    return sum;
  }

  sum = term + sum;
  return sumOfAPSeries(term + diff, diff, nTerms, currentTerm + 1, sum);
}

function sumOfAP(term, diff, nTerms) {
  return sumOfAPSeries(term, diff, nTerms, 0, 0);
}

function detailedMessage(term, diff, nTerms, expected, actual, description) {
  return `❌ ${description}\n
  first term[${term}], diff[${diff}], n terms[${nTerms}]\n
  expected: ${expected}\n
  actual: ${actual}`;
}

function composeMsg(term, diff, nTerms, expected, actual, description) {
  if (expected === actual) {
    return `✅ ${description}`;
  }
  return detailedMessage(term, diff, nTerms, expected, actual, description);
}

function testSumOfAP(description, term, diff, nTerms, expected) {
  const actual = sumOfAP(term, diff, nTerms);

  console.log(composeMsg(term, diff, nTerms, expected, actual, description));
}

function testAll() {
  testSumOfAP('sum of first 5 natural numbers', 1, 1, 5, 15);
  testSumOfAP('sum of first 5 whole numbers', 0, 1, 5, 10);
  testSumOfAP('sum of first 10 even numbers', 0, 2, 10, 90);
  testSumOfAP('sum of first 10 odd numbers', 1, 2, 10, 100);
  testSumOfAP('first term is above 5', 10, 2, 10, 190);
  testSumOfAP('sum of one term', 10, 2, 1, 10);
  testSumOfAP('sum of zero terms', 10, 2, 0, 0);
  testSumOfAP('sum of a term with same firstTerm & difference', 2, 2, 1, 2);
  testSumOfAP('first term is negative', -2, 2, 5, 10);
  testSumOfAP('difference is negative', 6, -3, 5, 0);
}

testAll();